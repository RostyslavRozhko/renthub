<?php

 nocache_headers();
 
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
    <head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
        <meta name="google-site-verification" content="OGgvvuzcDgXZ1nHpHGlL8g9HeNK7bJ9BzqW3BX7wf7A" />
        <title>
            <?php
            /*
             * Print the <title> tag based on what is being viewed.
             */
            global $page, $paged;

            wp_title('|', true, 'right');

            // Add the blog name.
            bloginfo('name');

            // Add the blog description for the home/front page.
            $site_description = get_bloginfo('description', 'display');
            if ($site_description && ( is_home() || is_front_page() ))
                echo " | $site_description";

            // Add a page number if necessary:
            if ($paged >= 2 || $page >= 2)
                echo ' | ' . sprintf(__(PAGE . ' %s', THEME_SLUG), max($paged, $page));
            ?>
        </title>
        <?php
        if (is_home()) {
            if (cc_get_option('cc_keyword') != '') {
                ?>
                <meta name="keywords" content="<?php echo cc_get_option('cc_keyword'); ?>" />
                <?php
            }
            ?>
            <?php if (cc_get_option('cc_description') != '') { ?>
                <meta name="description" content="<?php echo cc_get_option('cc_description'); ?>" />
                <?php
            }
            ?>
            <?php if (cc_get_option('cc_author') != '') { ?>
                <meta name="author" content="<?php echo cc_get_option('cc_author'); ?>" />
                <?php
            }
        }
        ?>
        <link rel="profile" href="http://gmpg.org/xfn/11" />
        <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
		<link href="https://fonts.googleapis.com/css?family=Fira+Sans:300,400,700" rel="stylesheet">
       <!--[if IE]>
        <script src="<?php echo TEMPLATEURL; ?>/js/html5shiv.js"></script>
        <![endif]-->
        <?php
        wp_head();
        ?>
        <link rel='stylesheet' href='<?php echo get_stylesheet_directory_uri() . "/style.css"; ?>' type='text/css' />        
    </head>
    <body <?php body_class() ?>>
<header class="header">
    <div class="wrap-nav">
        <div class="container">
            <div class="top-nav">
                <div class="logo_grid">                    
                        <?php if (!is_user_logged_in()): ?>
                           <a href="#0" class="btn btn_mobile btn_sign-in fright opendash">
                           <i class="fa fa-sign-in" aria-hidden="true"></i></a>
                         <?php endif; ?>
                         <?php if (is_user_logged_in()): ?>
                        <a href="#0" class="btn btn_mobile btn_account fright opendash">
                        <span class="link__username"><?php $current_user = wp_get_current_user(); echo $current_user->display_name; ?></span>
                        <i class="fa fa-user"aria-hidden="true"></i></i>
                        </a>
                        <?php endif; ?>
                    
                    <a class="logo" href="<?php echo home_url(); ?>"><img src="<?php if (cc_get_option('cc_logo') != '') { ?><?php echo cc_get_option('cc_logo'); ?><?php } else { ?><?php echo get_template_directory_uri(); ?>/images/logo.png<?php } ?>" alt="<?php bloginfo('name'); ?>" class="img-responsive fleft" />
                    </a>
                    <span class="logo-text__sublogo">Оренда будівеньної техніки</span>
                </div>
				
                <div class="login login_grid">
                    <div class="dash-item">
					
                        <?php if (!is_user_logged_in()) : ?>
            <a href="<?php echo home_url('ad-new/'); ?>" class="login__item  btnModal login__item__yellow">
                  <i class="fa fa-plus" aria-hidden="true"></i>
                    Подати оголошення
                </a>
                        <a href="#0" class="login__item  btnModal login__item__grey">Увійти</a>
                        
						<?php  else: ?>
						    
						<?php
						  $new_messages_num = fep_get_new_message_number();	?>
						  
                        <a href="<?php echo my_action_url('messagebox'); ?>" class="message-tooltip">
                            <span class="ico comments-mini"></span>
                            <?php if ($new_messages_num > 0) : ?>
                                <span class="badge badge_menu badge_header"><?php echo $new_messages_num; ?></span>
                            <?php else : ?>
                                <span class="tooltip-text">Немає нових повідомлень</span> 
							<?php endif ?>
                        </a>
                        <div class="dropopen">
                             <!--  <?php echo home_url('dashboard/'); ?> -->


                             <a href="#0" class="login__item dropopen_link" id="dashDrop"><?php $current_user = wp_get_current_user(); echo $current_user->display_name; ?></a>
                             <ul class="dashdrop mydropmenu">
                           
                            <li class="dropdown__item">
                                <a href="<?php echo home_url('ad-new/'); ?>">Створити оголошення</a>
                            </li>
                            <li class="dropdown__item">
                                <a href="<?php echo add_query_arg( array( 'action'=>'view' ), home_url( 'dashboard/' )); ?>">Мої оголошення</a>
                            </li>
                            <li class="dropdown__item">
                                <a href="<?php echo add_query_arg( array( 'action'=>'messagebox' ), home_url( 'dashboard/' )); ?>">Мої повідомлення</a>
                            </li>
                            <li class="dashdrop__exit dropdown__item">
                                <a href="<?php echo add_query_arg( array( 'action'=>'view' ), home_url( 'dashboard/' )); ?>">Мій кабінет</a>
                            </li>
                            <li class="dropdown__item">
                                <a href="<?php echo wp_logout_url(home_url()); ?>">Вийти</a>
                            </li>
                        </ul>
                         </div>
                           
                       <?php endif; ?>
					   
                    </div>
                </div>
            </div>
        </div>
		
    </div>
	
  <?php $no_logged = !is_user_logged_in() ? ' btnModal' : ''; ?>
	
  <?php if ( false ) : ?>
	
   <div class="wrap-carousel wrap-carousel_header">
        <div class="carousel-banner">
            <h1 class="carousel-banner__title"><?php echo __( 'Our cakes are worth your candles!', 'cc' ); ?></h1>
            <ul class="promo-text">
                <li class="promo-text__item"><span class="ico search-ico"></span>
                    <span class="promo-text__text"><?php echo __( 'Find sweet!', 'cc' ); ?></span>
                </li>
                <li class="promo-text__item"><span class="ico call-ico"></span>
                    <span class="promo-text__text"><?php echo __( 'Contact with the seller', 'cc' ); ?></span>
                </li>
                <li class="promo-text__item"><span class="ico sweet-ico"></span>
                    <span class="promo-text__text"><?php echo __( 'Get your order', 'cc' ); ?></span>
                </li>
            </ul>
            <a href="<?php echo home_url('ad-new/'); ?>" class="btn btn_lblue btn_sm<?php echo $no_logged; ?>"><?php echo __( 'Post an Ad', 'cc' ); ?></a>
        </div>
        <div class="slick carousel">
            <div class="carousel__item">
                <div class="carousel__slide carousel__slide_bg"></div>
            </div>
            <div class="carousel__item">
                <div class="carousel__slide carousel__slide_bg"></div>
            </div>
            <div class="carousel__item">
                <div class="carousel__slide carousel__slide_bg"></div>
            </div>
        </div>
    </div>
	
	<?php elseif( false ) : ?>
	
	<div class="wrap-carousel wrap-carousel_other">
        <div class="header__banner header__banner_other carousel__slide_other">
            <div class="tin"></div>
            <div class="container">
                <div class="wrap-carousel__item wrap-carousel__item_hide">
                    <h1 class="carousel-banner__title carousel-banner__title_text"><?php echo __( 'Buy sweets', 'cc' ); ?></h1>
                    <div class="promo-text_full"><?php echo __( 'Search sweets in Sweetico catalog,<br />buy and leave feedback.', 'cc' ); ?></div>
                    <span class="ico down-ico"></span>
                </div>
                <div class="wrap-carousel__item">
                    <h1 class="carousel-banner__title carousel-banner__title_text"><?php echo __( 'Add ads', 'cc' ); ?></h1>
                    <div class="promo-text promo-text_full"><?php echo __( 'If you are a confectioner and want to sell your own pastries - add ads and find your sweet tooth.', 'cc' ); ?></div>
                    <a href="<?php echo home_url('ad-new/'); ?>" class="btn btn_sm btn_lblue<?php echo $no_logged; ?>"><?php echo __( 'Post an Ad', 'cc' ); ?></a>
                </div>
            </div>
        </div>
    </div>
	
	<?php endif; ?>
	
	<?php
	  $lang = ( pll_current_language() != 'uk' ) ? '-'.pll_current_language() : '';
	  $class = is_singular( 'ad' ) ? ' search-grp_top' : '';
	?>
	
	<?php if( !is_page( 'dashboard' ) && !is_page( 'ad-new' ) ) : ?>
	
	<div class="search-grp search-grp_header<?php echo $class; ?>">
        <div class="container">
            <form action="<?php echo home_url('search'.$lang.'/'); ?>" method="get" class="form_srch-header">
                <!-- <div class="input-wrp input-wrp_grid">
                    <a href="<?php echo home_url('cate/akumuliatorni-instrumenty/'); ?>" class="banners-add__mobile-btn">Категорії оголошень</a>
                </div> -->
                <div class="search-arrow__container">
                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/share.svg" class="search-arrow__icon" />
                    <div class="search-arrow__text">Пошук</div>                    
                </div>
                <div class="input-wrp input-wrp_grid">
                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/magnifying-glass-2.svg" class="input-wrp__ico search-icon-input"></span>
                    <input type="text" class="input input_srch-header" placeholder="Я шукаю..." name="search_for" value="" />
                </div>
                <div class="input-wrp input-wrp_grid">
                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/flag.svg" class="input-wrp__ico search-icon-input"></span>
                    <input type="text" id="s_address" class="input input_srch-header" placeholder="Вся Україна" name="address" value="" />
                    <input type="hidden" id="s_city_id" class="input input_add" name="search_loc" value="" />
                </div>
                <div class="input-wrp input-wrp_btn">
				    <input type="submit" class="btn btn_srch btn_lg" value="Знайти"/>
                <!--<a href="<?php if (cc_get_option('cc_logo') != '') { ?><?php echo cc_get_option('cc_logo'); ?><?php } else { ?><?php echo get_template_directory_uri(); ?>/images/logo.png<?php } ?>" class="btn btn_yelow btn_srch btn_lg fancybox">Пошук</a>-->
                </div>
            </form>
        </div>
    </div>
	
	<?php endif; ?>
	
</header>

<?php if (!is_user_logged_in()) get_template_part('ajax', 'auth'); ?>
