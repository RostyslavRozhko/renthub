<?php
/**
 * Template Name: Template Registration Success
 *
 */
  get_header();
?>
    <div class="container">
	  <div class = "thanks">
        <h1><?php echo __( 'Check your email to continue activation!', 'cc' ); ?></h1>
      </div>
    </div>

<?php get_footer(); ?>
