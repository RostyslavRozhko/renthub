 <?php
  get_header();
  
  $s_to = isset( $_REQUEST['search_loc'] ) ? $_REQUEST['search_loc'] : '';
  $address = isset( $_REQUEST['address'] ) ? $_REQUEST['address'] : '';
 ?>

<div class="container">

    <div><?php get_sidebar('ad'); ?></div>
  
    <div class="cat-main">
      <div class="active-title"><span><?php single_cat_title(); ?></span></div>
    <?php
        $wp_query->query_vars[CUSTOM_CAT_TYPE];
        foreach ($wp_query as $query) {
            //$current_cat_arr[] = $query->slug;
            if( is_object($query) && isset( $query->term_id )) $current_cat_arr[] = $query->term_id;
        }
        $current_cat_val = array_filter($current_cat_arr);
        $current_id = current($current_cat_val);
        $limit = get_option('posts_per_page');
		$c = 0;
		$none = false;
		
		while ($c < 2) :
		
		if ($c == 0) $ad_type = 'pro';
		else $ad_type = 'free';
		$s_prem_posts = sweet_cat_search($current_id, $s_to, $ad_type);
        
		if ($s_prem_posts['result']) :
          foreach ($s_prem_posts['result'] as $s_post):
			$user_info = get_userdata($s_post->post_author);
        ?>
	    <div class="cat-item">
        <div class="product-item">
        <div class="product-item__img">
            <?php echo ad_thumbnail(); ?>
        </div>
        <a href="<?php the_permalink() ?>" class="product-item__container-title">
          <div class="product-item__title">
             <?php echo title_excerpt(); ?>
          </div>
          <?php echo price_output(); ?>
        </a>
    </div>
        </div>
    
	    <?php
          endforeach;
	    wp_reset_query();
	    else :
	      if( $c == 0 ) $none = true;
		  if( $c == 1 && $none ) :
	    ?>
       
        <div class="fanks__title fanks__title_category"><?php echo __( 'This category does not include ads', 'cc' ); ?></div> 
        
      
	    <?php endif; endif; $c++; endwhile; ?>
	  
	</div>
</div>

<?php get_footer(); ?>
