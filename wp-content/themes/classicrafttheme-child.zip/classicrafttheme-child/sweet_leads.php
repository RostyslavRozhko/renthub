<?php

  $captcha1 = rand(0, 9);
  $captcha2 = rand(0, 9);
  $cc_sbs_captcha = $captcha1 + $captcha2;
?>
    <form id="send-msg" method="post">
      <div class="form form_send-msg clearfix">
      <h3 class="advert__mess-title">Написати повідомлення</h3>
	  <?php if( $phone ) : ?>
      <div class="tel tel__bottom">
          <img class="tel-icon" src="<?php echo get_stylesheet_directory_uri(); ?>/img/call-answer-yellow.svg" />
          <span id="tel<?php echo $post->ID; ?>" class="nuber-tel nuber-tel_big"></span>
          <span class="btn btn_view" id="viewbtn">Відкрити</span>
      </div>
	  <?php endif; ?>
	  
        <div>
	      <textarea name="message_content" id="message" class="required textarea textarea_mess" placeholder="<?php echo __( 'Ask the manufacturer', 'cc' ); ?>"></textarea>
        </div>

        <div class="input-wrp input-wrp_block">
          <div>
            <div class="input-wrp input-wrp_block">
              <div class="col6 nopaddingl">
                <input class="captcha required input input_add" id="captcha" placeholder="<?php echo $captcha1 . ' + ' . $captcha2; ?>=?" type="text" name="captcha" value="" />
              </div>
              <div class="col6 nopaddingl">
              <div class="full nopadding rigth">
                <div class="wrap-btnsend">
                  <input type="hidden" id="captchacode" name="captchacode" value="<?php echo $cc_sbs_captcha; ?>" />
                  <input type="hidden" id="message_to" value="<?php echo $author_id; ?>" />
                        <input type="hidden" id="message_title" value="<?php echo 'Message from '.$current_user->nickname; ?>" />
                        <input type="hidden" id="message_from" value="<?php echo $user_ID; ?>" />
                        <input type="hidden" id="parent_id" value="0" />
                      <input type="hidden" id="token" value="<?php echo fep_create_nonce('new_message'); ?>" />
                        <input type="submit" name="new_message" class="btn btn_send" value="Написати автору"/>
                      </div>  
                    </div>  
                  </div>
              </div>
            </div>
          </div>
        </div>
		

    </form>
