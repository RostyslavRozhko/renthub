<?php
/**
 * Template Name: Template Search 
 */
 
  get_header();
?>
<div class="container">

    <div class="full">
    <?php
        $s_for = isset( $_REQUEST['search_for'] ) ? $_REQUEST['search_for'] : '';
        $s_cat = isset( $_REQUEST['select_cat'] ) ? $_REQUEST['select_cat'] : '';
        $s_to = isset( $_REQUEST['search_loc'] ) ? $_REQUEST['search_loc'] : '';

		$result_query = sweet_search($s_for, $s_to);
        if (isset($_GET['pn'])) { // Get pn from URL vars if it is present
          $pn = preg_replace('#[^0-9]#i', '', $_GET['pn']); // filter everything but numbers for security(new)
        } else { // If the pn URL variable is not present force it to be value of page number 1
        $pn = 1;
        }

        $itemsPerPage = 20;

        $lastPage = ceil($result_query['query'] / $itemsPerPage);

        if ($pn < 1) { // If it is less than 1
          $pn = 1; // force if to be 1
        } else if ($pn > $lastPage) { // if it is greater than $lastpage
          $pn = $lastPage; // force it to be $lastpage's value
        }

        $centerPages = "";
        $sub1 = $pn - 1;
        $sub2 = $pn - 2;
        $add1 = $pn + 1;
        $add2 = $pn + 2;
        if ($pn == 1) {
          $centerPages .= '<li><a class="current" href="">' . $pn . '</a></li>';
          $centerPages .= '<li> <a href="' . site_url(CC_SEARCH . "/?action=lead&pn=$add1&search_for=$s_for&select_cat=$s_cat&search_loc=$s_to") . '">' . $add1 . '</a></li>';
        } else if ($pn == $lastPage) {
          $centerPages .= '<li> <a href="' . site_url(CC_SEARCH . "/?action=lead&pn=$sub1&search_for=$s_for&select_cat=$s_cat&search_loc=$s_to") . '">' . $sub1 . '</a></li>';
          $centerPages .= '<li><a class="current" href="">' . $pn . '</a></li>';
        } else if ($pn > 2 && $pn < ($lastPage - 1)) {
          $centerPages .= '<li><a href="' . site_url(CC_SEARCH . "/?action=lead&pn=$sub2&search_for=$s_for&select_cat=$s_cat&search_loc=$s_to") . '">' . $sub2 . '</a></li>';
          $centerPages .= '<li><a href="' . site_url(CC_SEARCH . "/?action=lead&pn=$sub1&search_for=$s_for&select_cat=$s_cat&search_loc=$s_to") . '">' . $sub1 . '</a></li>';
          $centerPages .= '<li><a class="current" href="">' . $pn . '</a></li>';
          $centerPages .= '<li><a href="' . site_url(CC_SEARCH . "/?action=lead&pn=$add2&search_for=$s_for&select_cat=$s_cat&search_loc=$s_to") . '">' . $add1 . '</a></li>';
          $centerPages .= '<li><a href="' . site_url(CC_SEARCH . "/?action=lead&pn=$add2&search_for=$s_for&select_cat=$s_cat&search_loc=$s_to") . '">' . $add2 . '</a></li>';
        } else if ($pn > 1 && $pn < $lastPage) {
          $centerPages .= '<li> <a href="' . site_url(CC_SEARCH . "/?action=lead&pn=$sub1&search_for=$s_for&select_cat=$s_cat&search_loc=$s_to") . '">' . $sub1 . '</a> </li>';
          $centerPages .= '<li><a class="current" href="">' . $pn . '</a></li>';
          $centerPages .= '<li><a href="' . site_url(CC_SEARCH . "/?action=lead&pn=$add1&search_for=$s_for&select_cat=$s_cat&search_loc=$s_to") . '">' . $add1 . '</a></li>';
        }

        $limit = 'LIMIT ' . ($pn - 1) * $itemsPerPage . ',' . $itemsPerPage;
        $paginationDisplay = "<ul class='paginate'>"; // Initialize the pagination output variable
        if ($lastPage != "1") {
          //$paginationDisplay .= 'Page <strong>' . $pn . '</strong> of ' . $lastPage . '&nbsp;  &nbsp;  &nbsp; ';

        if ($pn != 1) {
          $previous = $pn - 1;
          $paginationDisplay .= '<li><a href="' . site_url(CC_SEARCH . "/?action=lead&pn=$previous&search_for=$s_for&select_cat=$s_cat&search_loc=$s_to") . '"> Back</a></li>';
        }
        $paginationDisplay .= $centerPages;
          if ($pn != $lastPage) {
            $nextPage = $pn + 1;
            $paginationDisplay .= '<li><a href="' . site_url(CC_SEARCH . "/?action=lead&pn=$nextPage&search_for=$s_for&select_cat=$s_cat&search_loc=$s_to") . '"> Next</a></li> ';
          }
        }
        $paginationDisplay .= '</ul>';

        $address = isset( $_REQUEST['address'] ) ? stripslashes( $_REQUEST['address'] ) : '';
		$address = $address ? ' у місті' . ' "' . $address . '"' : '';
		$search_text = $s_for ? '"' . $s_for . '" ' : '';
        $search_header = 'Результати пошуку' . $search_text . $address;
    ?>
        <div class="active-title"><span><?php echo $search_header; ?></span></div>
        <?php
     $classifields = sweet_search($s_for, $s_to, $limit);
        // $classifields = sweet_search($s_for, $s_to);

        if ($classifields['result']) :
          foreach ($classifields['result'] as $cfield):
                                        
            $ad_type = get_post_meta($cfield->ID, 'cc_add_type', true);
            $user_info = get_userdata($cfield->post_author);
		 
          //$taxonomies = get_the_term_list($cfield->ID, CUSTOM_CAT_TYPE, '', ',', '');
        ?>
        <div class="cat-item">
          <div class="product-item">
            <div class="product-item__img">
                            <?php
                                if( $ad_type == 'pro' ) echo '<div class="group-product_premium__label">Преміум</div>'; 
                                echo ad_thumbnail( $cfield->ID );
                              ?>
            </div>
                            <a href="<?php the_permalink($cfield->ID) ?>" class="product-item__container-title">
                              <div class="product-item__title">
                                 <?php echo title_excerpt($cfield->ID); ?>
                              </div>
                              <?php echo price_output($cfield->ID); ?>
                            </a>
              </div>
          </div>
	    <?php endforeach; wp_reset_query(); else : ?>

         <div class="fanks fanks_notfound">
                <span class="ico nofound-ico"></span>
                <div class="fanks__title"><?php echo __( 'Nothing found...', 'cc' ); ?></div>
                <div class="fanks__subtitle"><?php echo __( 'Sorry, at Sweetico there is no ads for your request!', 'cc' ); ?></div>
                <p><?php echo __( 'Please try another search phrase or go back to the main page.', 'cc' ); ?></p>
                <div class="text-center">
                    <a href="<?php echo home_url(); ?>" class="btn btn_lblue"><?php echo __( 'Home', 'cc' ); ?></a>
                </div>
            </div>

        <?php endif; ?>

        <div class="paging"><span style="float:right;"><?php echo $paginationDisplay; ?></span></div>
        <div class="clear"></div>

    </div>
</div>
	
<?php get_footer(); ?>
