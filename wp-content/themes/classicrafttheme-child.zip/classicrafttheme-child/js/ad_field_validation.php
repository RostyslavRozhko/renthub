<script type="text/javascript">
  jQuery(document).ready(function(){
		
	var adForm = jQuery("#newAd");
	var editAdForm = jQuery("#edit_post_form");

    var cc_title = jQuery("#title");   
    var cc_desc = jQuery("#cc_desc");
    var cc_price = jQuery("#cc_price");
    var cc_address_list = jQuery("#cc_address_list");
    var cc_address = jQuery("#cc_address");
	const address_list = jQuery('#address_list')

    var cat_selects = jQuery("#ad-categories select");
    var values = [];

    var cats_error = jQuery(".cats_error");
    const desc_error = jQuery('.desc_error')
    var photo_error = jQuery(".photo_error");
	
	if( jQuery("#maincat").val() == '98' ) {
      jQuery("#taste-ul, #event-ul").fadeIn();
    }

    jQuery("#maincat").on("change", function(e) {
        category_ID = jQuery(this).val();
        var cat_ul = jQuery("#maincat-li").parent();

        cat_ul.find('#subcat-li').remove();

        if( category_ID == '98' ) {
            jQuery("#taste-ul, #event-ul").fadeIn();
			jQuery("#subcat").val('');
        }
		// If not Cakes
        else {
          jQuery("#taste-ul, #event-ul").fadeOut();
		  jQuery("#taste, #event").val('');
		  cat_ul.append('<li class="input-wrp input-wrp_block" id="subcat-li"></li>');
  
          jQuery.ajax({
            type: 'POST',
            dataType: 'json',
            url: "<?php echo admin_url( 'admin-ajax.php' ); ?>",
            data: {
                'action': 'getSubCategories',
                'catID': category_ID,
            },
            success: function (data) {
                if (data == "") {
                  jQuery("#subcat-li").fadeOut();
                }
                else {
                  jQuery("#subcat-li").html(data).fadeIn();
                  jQuery("#subcat").styler();
                  jQuery("#subcat").change(function() {
                    var values = jQuery('#ad-categories select').map(function () {
                      if( this.value > 0 ) return this.value;
                    }).get();
                    jQuery("#chosenCategory").val(values)
                  });
                }
            }
          });
		}
		// End - not Cakes

        e.preventDefault();
    });

    cat_selects.change(function() {
	  cats_error.text("");
      values = jQuery(cat_selects).map(function () {
        if( this.value > 0 ) return this.value;
      }).get();
	  jQuery("#chosenCategory").val(values);
    });
	
	
	    function validate_cat(){
            if( !jQuery("#chosenCategory").val()) {
                cats_error.text("Оберіть категорію");
				cats_error.addClass("error");
                return false;
            }else{
                cats_error.text("");
				cats_error.removeClass("error");
                return true;
            }
        }
   
		
        function validate_title(){
            if(cc_title.val() == ''){
				cc_title.addClass("error");
                cc_title.attr("placeholder", "Введіть назву");
                cc_title.css('border', 'solid 1px red');
                cc_title.css('background-color', '#ffece8');
                return false;
            }else{
				cc_title.removeClass("error");
                cc_title.css('border', 'none');
                cc_title.css('background-color', '');
                return true;
            }
        }
        cc_title.blur(validate_title);
        cc_title.keyup(validate_title);
		
		function validate_price(){
            if( cc_price.val() == '' && !jQuery("#custom-price").is(":checked") ){
				cc_price.addClass("error");
                cc_price.attr("placeholder", "Введіть ціну");
                cc_price.css('border', 'solid 1px red');
                cc_price.css('background-color', '#ffece8');
                return false;
            }else{
				cc_price.removeClass("error");
                cc_price.css('border', 'none');
                cc_price.css('background-color', '');
                return true;
            }
        }
        cc_price.blur(validate_price);
        cc_price.keyup(validate_price);
		
		cc_address.change(function() {
			cc_address.removeClass("error");
            cc_address.css('border', 'none');
            cc_address.css('background-color', '');
        });
		function validate_address(){
            if( cc_address_list.val() == '' || cc_address_list.val() == '[]'){
				cc_address.val('');
				cc_address.addClass("error");
                cc_address.css('border', 'solid 1px red');
                cc_address.css('background-color', '#ffece8');
                return false;
            }
			else return true;
        }
		
  function validate_desc() {
    const content = tinymce.activeEditor.getContent()
    cc_desc.text(content)
    if(cc_desc.val() == "" || cc_desc.val().length < 150 ) {
			desc_error.addClass("error")
      desc_error.text('Введіть опис оголошення (мінімум 150 символів)')
      return false;
    } else {
			desc_error.removeClass("error");
      desc_error.text('')
      return true;
    }
  }
  desc_error.blur(validate_desc);
  desc_error.keyup(validate_desc);
		
		function validate_photo(){
            if( !jQuery("#img1").val() & !jQuery("#img2").val() & !jQuery("#img3").val() ) {
                photo_error.text("Завантажте 1 фото");
				photo_error.addClass("error");
                return false;
            }else{
                photo_error.text("");
				photo_error.removeClass("error");
                return true;
            }
        }


		adForm.submit(function(){
          if(validate_title() & validate_desc() & validate_cat() & validate_price() & validate_address() & validate_photo())
            return true;
          else {
		    $('html, body').animate({
              scrollTop: $('.error').offset().top -70
            }, 'slow');
		    return false;
		  }
        });
		
		editAdForm.submit(function(){
          if(validate_title() & validate_desc() & validate_cat() & validate_price() & validate_address() & validate_photo())
            return true;
          else {
		    $('html, body').animate({
              scrollTop: $('.error').offset().top -70
            }, 'slow');
		    return false;
		  }
        });
    });
</script>