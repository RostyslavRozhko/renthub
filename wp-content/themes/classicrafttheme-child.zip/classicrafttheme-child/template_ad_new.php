<?php
/**
 * Template Name: Template Ad New
 */
### Prevent Caching
nocache_headers();
auth_redirect_home();

function cc_submit_form_process() {
    $posted = array();

    $fields = array(
        'cc_title',
        'cc_description',
        'cc_category',
        'cc_price',
		'cc_price_type',
        'custom-price',
        'cc_address_list',
		'cc_city_id',
        'cc_state',
        'img1',
        'img2',
        'img3',
    );
    //Fecth form values
    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            $posted[$field] = stripcslashes(trim($_POST[$field]));
        }
    }

    $errors = new WP_Error();

    $submit_form_results = array(
        'errors' => $errors,
        'posted' => $posted
    );
    return $submit_form_results;
}

global $user_ID;
$posted = array();
$errors = new WP_Error();

$value = cc_submit_form_process();

$errors = $value['errors'];
$posted = $value['posted'];

$success = false;

if ($errors && sizeof($errors) > 0 && $errors->get_error_code()) {


} else {
    $check_submit = get_option('cc_check_submit');
    if( isset($_REQUEST['cc_check_submit']) && $_REQUEST['cc_check_submit'] != $check_submit ) {
	    //isset($_POST['cc_submit']) && $_POST['cc_submit'] ) {

            //Approval needed
            if (isset($_REQUEST['pay_method']) && $_POST['total_price'] > 0) {
                //$post_status = 'pending';
                $post_status = 'publish';
            } elseif (!isset($pay_method) && $_POST['total_price'] == 0) {
                $status = strtolower(cc_get_option('cc_freead'));
                if ($status == 'pending'):
                    $post_status = 'pending';
                endif;
                if ($status == 'publish'):
                    $post_status = 'publish';
                endif;
                if (!$status) {
                    $post_status = 'pending';
                }
            }

			$post_title = $wpdb->escape($posted['cc_title']);

            ## Create Post
            $category = array_map('intval', explode(',', $posted['cc_category']));
            $cc_my_post = array(
                'post_content' => $wpdb->escape($posted['cc_description']),
                'post_title' => $post_title,
                'post_status' => $post_status,
                'post_author' => $user_ID,
                'post_type' => POST_TYPE,
            );
            $post_id = wp_insert_post($cc_my_post);

            // Check either post created or not
            if ( $post_id && !is_wp_error($post_id) )
            {
              $success = true;

			  wp_set_object_terms($post_id, $category, $taxonomy = CUSTOM_CAT_TYPE);

              add_post_meta($post_id, 'cc_address_list', $posted['cc_address_list'], true);
				add_post_meta($post_id, 'cc_city_id', $posted['cc_city_id'], true);
			  if( isset($posted['custom-price']) )
                add_post_meta($post_id, 'custom-price', $posted['custom-price'], true);
			  else {
				add_post_meta($post_id, 'cc_price', $posted['cc_price'], true);
                add_post_meta($post_id, 'cc_price_type', $posted['cc_price_type'], true);
              }
              
              add_post_meta($post_id, 'cc_state', $posted['cc_state'], true);

			  add_post_meta($post_id, 'img1', $posted['img1'], true);
			  add_post_meta($post_id, 'img2', $posted['img2'], true);
			  add_post_meta($post_id, 'img3', $posted['img3'], true);

			  if( !$posted['img1'] && $posted['img2'] ) {
				  update_post_meta($post_id, 'img1', $posted['img2']);
			      update_post_meta($post_id, 'img2', '');
			  }

			  if( !$posted['img1'] && !$posted['img2'] && $posted['img3'] ) {
				  update_post_meta($post_id, 'img1', $posted['img3']);
			      update_post_meta($post_id, 'img3', '');
			  }

              //Save add type value
              update_post_meta($post_id, 'cc_add_type', 'free');

              $pkg_type = $_POST['package_type'] ? $_POST['package_type'] : 'pkg_free';

              //set expiry duration
              cc_set_expiry($post_id, $pkg_type);

			  // Email
			  $blogname = wp_specialchars_decode(get_option('blogname'), ENT_QUOTES);
			  $admin_email = get_option('admin_email');
	          $headers = array(
	           'Content-Type: text/html; charset=UTF-8',
	           'From: ' . $blogname . ' <' . $admin_email . '>' . "\r\n",
	          );
			  $permalink = get_permalink( $post_id );
			  $img_url = ad_thumbnail_url ( $post_id );
			  ob_start();
	          include( get_stylesheet_directory() . '/email/complete.php');
	          $message = ob_get_clean();
              wp_mail($current_user->user_email, __('Congratulations, your ad has been published', 'cc'), $message, $headers);

			  // email to admin
			  $message = admin_url( 'post.php?post=' . $post_id ) . '&action=edit';
			  wp_mail( $admin_email, __('New Ad', 'cc'), $message );


			  //Validate to prevent duplicate submission
              update_option('cc_check_submit', $_REQUEST['cc_check_submit']);

			  $featured_home = isset( $_POST['feature_h'] ) ? 'on' : '';
              $featured_cate = isset( $_POST['feature_c'] ) ? 'on' : '';

              if ( isset($_REQUEST['pay_method']) && $_REQUEST['pay_method'] != '' && $_POST['total_price'] > 0 ) {

                if( file_exists(get_stylesheet_directory().'/gateways/liqpay/liqpay.php' )) :
                    include_once( get_stylesheet_directory().'/gateways/liqpay/liqpay.php' );
                endif;
              }
			}
        }
}
get_header();
require_once( get_stylesheet_directory().'/js/ad_field_validation.php' );

?>
<section class="grey-background">
<div class="container">
<section class="add-ad">

<?php if( $success ) : ?>

    <div class="fanks">
        <span class="ico fanks-ico"></span>
        <div class="fanks__title">Дякую!</div>
        <div class="fanks__subtitle">Ваше оголошення додано та відправлено на перевірку!</div>
        <p>Коли ваше оголошення буде активоване, ми надішлево вам Email повідомлення. Зазвичай це займає менше 15 хвилин.</p>
        <div class="text-center">
            <a href="<?php echo site_url('dashboard'); ?>" class="dashboard-btn"></span>Мій кабінет</a>
            <a href="<?php echo home_url('ad-new/'); ?>" class="login__item  btnModal login__item__yellow">
                  <i class="fa fa-plus" aria-hidden="true"></i>
                    Подати оголошення
                </a>
        </div>
    </div>

<?php else : ?>

    <div class="add">
        <div class="container">
            <div class="add__title text-center">
                Додати оголошення
            </div>

            <form id="newAd" name="add_post_form" method="post" style="display: block;">
                <ul class="add__wrap">

                    <li class="add__step">

                        <div class="add__form-item clearfix">
                        <div class="step__title">Додати опис<span class="add__step-num">1</span></div>
                        

                            <div class="input-wrp input-wrp_block add__block">    
                                <div class="form__title req">Назва оголошення</div>
                                <div class="input-wrp input-wrp_block">
                                    <span class="max-text">Максимум 100 символів</span>
                                    <input type="text" id="title" class="input_add" name="cc_title" placeholder="Введіть назву">
                                </div>
                            </div>

                            <div class="input-wrp input-wrp_block add__block">                            
                                <div class="col6 nopaddingl">
                                    <div class="req form__title">Оберіть категорію</div>                                        
                                    <span class="cats_error"></span>
                                    <div id="ad-categories">
                                    <div class="input-wrp input-wrp_block ">
                                        <?php my_dropdown_categories( 'maincat', 'Категорія' ); ?>
                                    </div>
                                    </div>
                                    <input id="chosenCategory" name="cc_category" type="hidden" value="" />
                                </div>
                                <div class="col6 nopaddingr">
                                    <div class="req form__title">Стан</div>
                                    <div class="input-wrp input-wrp_block ">
                                        <select name="cc_state" class="input_add">
                                            <option value="new">Нове</option>
                                            <option value="used">Вживане</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="input-wrp input-wrp_block add__block" id="price-block">
                                <div class="col6 nopaddingl">
                                    <div class="req form__title">Ціна, грн</div>
                                    <div class="input-wrp input-wrp_block">
                                        <input type="number" type="text" class="input_add" placeholder="Введіть ціну" min="1" max="999" id="cc_price" name="cc_price">
                                    </div>
                                </div>
                                <div class="col6 nopaddingr">
                                    <div class="req form__title">Ціна за</div>
                                    <div class="input-wrp input-wrp_block">
                                        <select name="cc_price_type" class="input_add">
                                            <option value="hour">Годину</option>
                                            <option value="day">День</option>
                                            <option value="service">Послугу</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="add__block">
                              <label>
                                  <input type="checkbox" class="add__check" value="1" name="custom-price" id="custom-price">Ціна за домовленістю
                              </label>
                            </div>
                            <div class="req form__title">Опис оголошення</div>
                            <div class="input-wrp input-wrp_block">
                                <span class="max-text">Максимум 1000 символів</span>
                                <span class="desc_error"></span>
                                <textarea name="cc_description" id="cc_desc" class="textarea textarea_mess" placeholder="Додайте опис до вашого оголошення"></textarea>
                            </div>
                        </div>
                    </li>

                    <li class="add__step add__step__container">
                        <div class="step__title">Додати зображення<span class="add__step-num">2</span></div>
                        <span class="photo_error"></span>
						<?php $id1 = "img1"; $id2 = "img2"; $id3 = "img3"; ?>

                        <div class="add__photo-grid-container">
					    <div class="add__upload_big ">
                            <div class="upload_img-wrp">
                                <div class="add__upload">
                                    <div class="add__upload-text">
                                        <div class="div add__photo-title">Завантажте фото</div>
                                        <p>Завантажте фото своєї техніки у галерею. Пам'ятайте, що чим краще картинка - тим більше людей звернуть увагу на Ваше оголошення.</p>
                                        <?php my_photo_markup( $id1 ); ?>
                                    </div>
                                </div>
								<div class="plupload-thumbs hide" id="<?php echo $id1; ?>plupload-thumbs">
                                </div>
                            </div>
                        </div>

                            <div class="small-top">
                                <div class="upload_img-wrp">
                                  <?php my_photo_markup( $id2 ); ?>
                                  <div class="plupload-thumbs hide" id="<?php echo $id2; ?>plupload-thumbs">
                                  </div>
                                </div>
                            </div>

                            <div class="small-bot">
                                <div class="upload_img-wrp">
							      <?php my_photo_markup( $id3 ); ?>
                                  <div class="plupload-thumbs hide" id="<?php echo $id3; ?>plupload-thumbs">
                                  </div>
                                </div>
                            </div>
                        </div>

                    </li>

                    <li class="add__step">
                        <div class="add__form-item add__form-item_contact">
                            <div class="step__title">Де знаходиться техніка?<span class="add__step-num">3</span></div>                            
							<div id='address_list'></div>                            
                            <div class="req form__title">Вкажіть адресу</div>
                            <div class="input-wrp input-wrp_block">
								<span class="max-text">Максимум 4 адреси</span>
								<input type="hidden" name="cc_address_list" id="cc_address_list" value=''/>
                                <input type="hidden" name="cc_city_id" id="cc_city_id" value=''/>
                                <div class="address-input__container">
                                    <input type="text" name="cc_address" id="cc_address" class="input_add noEnterSubmit" value='' placeholder="Адреса" />
                                    <input type="button" id="add_address" value="Додати" />
                                </div>
			                    <div id="map_canvas" style="height:350px; margin-top: 10px; position:relative;"  class="form_row clearfix"></div>
			                    <?php edit_map(); ?>
                            </div>
                        </div>
                    </li>

                    <li class="add__step add__step__container">

                        <div class="step__title">Варіанти розміщення<span class="add__step-num">4</span></div>
                      <?php

                        global $wpdb, $price_table_name;
						$packages = $wpdb->get_results("SELECT * FROM $price_table_name WHERE status=1");
                        if ($packages):
                          foreach ($packages as $package):
                            $valid_to = $package->validity_per;
                            if ($valid_to == 'D') $valid_to = "днів";
                            if ($valid_to == 'M') $valid_to = __( "Months", 'cc' );
                            if ($valid_to == 'Y') $valid_to = __( "Years", 'cc' );
                      ?>
						<div class="add__seo" >
                          <div class="inline-wrp">
                            <input type="radio" <?php if ($package->package_cost == 0) echo "checked='checked'"; ?> value="<?php echo $package->package_cost; ?>" name="price_select" id="<?php echo $package->package_type; ?>" class="radio">
                            <input type="hidden" class="<?php echo $package->package_type; ?>" name="<?php echo $package->package_type; ?>" value="<?php echo $package->validity; ?>"/>
                            <input type="hidden" class="<?php echo $package->package_type_period; ?>" name="<?php echo $package->package_type_period; ?>" value="<?php echo $package->validity_per; ?>"/>
                            <input type="hidden" class="is_recurring" name="is_recurring" value="<?php echo $package->is_recurring; ?>"/>
                            <input type="hidden" class="validity" name="validity" value="<?php echo $package->validity; ?>"/>
                            <input type="hidden" class="validity_per" name="validity_per" value="<?php echo $package->validity_per; ?>"/>
                            <input type="hidden" class="pkg_type" name="pkg_type" value="<?php echo $package->package_type; ?>"/>
                            <input type="hidden" class="is_featured" name="is_featured" value="<?php echo $package->is_featured; ?>"/>
                            <input type="hidden" id="price_title" name="price_title" value="<?php echo $package->price_title; ?>"/>
							<?php

							  if ( $package->package_cost == 0 ) echo '<img src="'.get_stylesheet_directory_uri().'/img/piggy-bank.svg" class="add__seo__icon" />';
							  else echo '<img src="'.get_stylesheet_directory_uri().'/img/crown.svg" class="add__seo__icon" />';
							?>
                            <label class="big-label" for="<?php echo $package->package_type; ?>">
                                <span class="big-label__title"><?php echo stripslashes(__($package->price_title,'cc')); ?></span>
								<p><?php echo __( 'Термін дії :', 'cc' ) .'&nbsp;'. $package->validity .'&nbsp;'. $valid_to . '<br>' . stripslashes(__($package->price_desc, 'cc')); ?></p>
                            </label>
                            <?php if( $package->package_cost != 0 ) : ?>
                            <div class="add__seo__price">
                                    <?php echo $package->package_cost; ?> грн
                          </div>

							<div class="big-label__option" id="featured">
                                <label>
							        <input type="checkbox" id="feature_h" name="feature_h" class="add__check" value="<?php echo $package->feature_amount; ?>"><?php echo __( 'Відображати як преміум на головній сторінці сайту', 'cc' ).' <b>+<span id="fhome">'.$package->feature_amount.'</span> '.cc_get_option('cc_currency').'</b>'; ?>
								</label>
                                <label>
                                    <input type="checkbox" id="feature_c" name="feature_c" class="add__check" value="<?php echo $package->feature_cat_amount; ?>"><?php echo __( 'Відображати як преміум на сторінці категорії', 'cc' ).' <b>+<span id="fhome">'.$package->feature_cat_amount.'</span> '.cc_get_option('cc_currency').'</b>'; ?>
								</label>
                            </div>

							<?php endif; ?>

                          </div>
                        </div>

					    <?php  endforeach; endif; ?>
                        <div class="form_row">
                            <input type="hidden" name="total_price" id="total_price" value="0"/>
                            <input type="hidden" name="package_title" id="package_title" value=""/>
                            <input type="hidden" name="package_validity" id="package_validity" value=""/>
                            <input type="hidden" name="package_validity_per" id="package_validity_per" value=""/>
                            <input type="hidden" name="package_type" id="package_type" value=""/>
                        </div>

                    </li>

                    <li class="last__step">

                      <div class="input-wrp input-wrp_block nopadding">
                        <div id="btnsend">
                          <a href="#0" class="add__btn" id="cc_submit"><span class="ico mail-ico"></span><?php echo __( 'Publish ad', 'cc' ); ?></a>
                        </div>
                        <div id="btnpay" class="hide">
                          <a href="#0" class="btn btn_green" id="cash">LIQPAY: Оплатити (<span></span> грн)</a>
                          <div id="pay-logos" class="add__step text-center">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/visa.png" alt="visa" class="img-responsive inline">
                          </div>
                        </div>
                      </div>

					  <input type="hidden" name="cc_check_submit" value="<?php echo rand(); ?>"/>

					  <ul id="payments">
                        <li id="liqpay">
                          <label class="r_lbl"><input  type="hidden" value="liqpay" id="liqpay_id" name="pay_method" checked="checked" /></label>
                        </li>
                      </ul>

                    </li>
                </ul>

            </form>
        </div>
    </div>

<?php endif; ?>

</section>
</div>
</section>

<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/js/package_price.js"></script>
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/js/placeholder.min.js"></script>
<script type="text/javascript">
    tinymce.init({
        selector: 'textarea',
        height: 300,
        menubar: false,
        plugins: ["lists", "placeholder"],
        toolbar: 'undo redo |  formatselect | bold italic backcolor  | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
        });
</script>

<?php get_footer(); ?>
