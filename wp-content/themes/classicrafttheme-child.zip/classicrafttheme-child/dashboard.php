<?php

  global $wpdb, $cc_leads_tbl_name, $current_user;
  $update_msg = '';

  if (isset($_REQUEST['action']) && $_REQUEST['action'] == "delete" && isset($_REQUEST['pid'])) {
    $id = $_REQUEST['pid'];
	delete_images( get_post_meta( $id, 'img1', true ));
	delete_images( get_post_meta( $id, 'img2', true ));
	delete_images( get_post_meta( $id, 'img3', true ));
	wp_delete_post($id);
	
    $update_msg = "Оголошення видалено";
  }

  if ( isset( $_POST['pay_method'] ) && $_POST['pay_method'] != '' && $_POST['total_price'] > 0 && isset( $_POST['post_id'] ))
  {
    $post_id = $_POST['post_id'];
	$post_title = get_the_title( $post_id );
    
	$featured_home = isset( $_POST['feature_h'] ) ? 'on' : '';
	$featured_cate = isset( $_POST['feature_c'] ) ? 'on' : '';

      if( file_exists(get_stylesheet_directory().'/gateways/liqpay/liqpay.php' ))
        include_once( get_stylesheet_directory().'/gateways/liqpay/liqpay.php' );
  }

?>
        <?php if( $update_msg ) echo notification_markup( $update_msg ); ?>
	
        <div class="profile profile-main">
            <div class="profile__add text-center">
                <a href="<?php echo home_url('ad-new/'); ?>" class="login__item login__item__yellow">
                      <i class="fa fa-plus" aria-hidden="true"></i>
                        Подати оголошення
                </a>
            </div>
            <div class="list__item__header">
              <div class="list__item__date-header list__item__header-text">Дата</div>
              <div class="list__item__img-header list__item__header-text">Зображення</div>
              <div class="list__item__price-header list__item__header-text">Вартість</div>
            </div>
       <?php
             $user_id = get_current_user_id();
             $limit = get_option('posts_per_page');
             $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
             $post_type = POST_TYPE;
             query_posts(array(
                "post_type" => $post_type,
                "posts_per_page" => $limit,
                "paged" => $paged,
                "author" => $user_id,
                'post_status' => 'publish, pending',
              ));

             if (have_posts()) :
                while (have_posts()): the_post();
                ?>
                  <?php $date = get_the_date(); ?>
                  <div class="list__item">
                    <div class="list__item__date"><?php echo the_time(); ?></br><?php echo $date; ?></div>
                    <div class="list__item__content">
                      <img src="<?php echo ad_thumbnail_url(); ?>" class="list__item__image" />
                      <div class="list__item__title-container">
                        <a href="<?php echo get_permalink(); ?>" class="list__item__title"><?php echo get_the_title(); ?></a>
                        <div class="list__itme__status">
                          <span class="list__item__status-title">Статус: </span>
                          <span class="list__item__status-value"><?php
                                if ($post->post_status == 'publish')
                                  echo __( 'Опубліковано' );
                                elseif ($post->post_status == 'pending')
                                  echo __( 'Очікує модерації' ); ?></span>
                        </div>
                      </div>
                    </div>
                    <div class="list__item__price"><?php echo price_output_clean(); ?></div>
                    <div class="list__item__menu">
                    <div class="dropopen">
                      <a href="#0" class="login__item dropopen_link list__item__3dot-container" id="dashDrop">
                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/menu-2.svg" class="list__item__3dot" />
                      </a>
                        <ul class="dashdrop mydropmenu">
                          <li class="dropdown__item">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/magnifying-glass.svg" class="dropdown-icon" />
                            <a href="<?php echo get_permalink(); ?>">Переглянути</a>
                          </li>
                          <li class="dropdown__item">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/edit.svg" class="dropdown-icon" />
                            <a href="<?php echo add_query_arg( array( 'action'=>'edit', 'pid'=>$post->ID ), home_url( 'dashboard/' )); ?>">Редагувати</a>
                          </li>
                          <?php if( get_post_meta( $post->ID, 'cc_add_type', true ) == 'free' ) : ?>
                            <li class="dropdown__item">
                              <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/star.svg" class="dropdown-icon" />
                              <a href="#modalPremium" id="makePremium<?php echo $post->ID; ?>" >Зробити преміум</a>
                            </li>
                          <?php endif; ?>
                          <li class="dropdown__item dashdrop__exit">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/power-button.svg" class="dropdown-icon" />
                            <a href="">Відключити</a>
                          </li>
                          <li class="dropdown__item dropdown__item__red">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/cancel-2.svg" class="dropdown-icon" />
                            <a href="<?php echo add_query_arg( array( 'action'=>'delete', 'pid'=>$post->ID ), home_url( 'dashboard/' )); ?>">Видалити</a>
                          </li>
                        </ul>
                    </div>
                    </div>
                  </div>
              <?php endwhile; ?>
			  
          <?php else: ?>
        
		      <div class="mess-info mess-info_center">
              У вас немає оголошень
          </div>

          <?php endif; ?>

          <?php wp_reset_query(); ?>
		 
        </div>
        
		<div class="modal modal_del hide" id="modalDel">
          <div class="modal__title modal__title_del">Ви справді хочете видалити оголошення?</div>
            <div class="modal__body modal__body_del">
              <a href="#0" class="btn btn_flat btn_del"><?php echo __( 'Delete', 'cc' ); ?></a>
              <a href="#0" class="btn btn_flat btn_nodel"><?php echo __( 'Later', 'cc' ); ?></a>
           </div>
        </div>

	   
<!-- Modal Premium Start -->
      <div class="modal modal_premium hide" id="modalPremium">
	  
	    <form name="edit_post_form" id="edit_post_form" action="<?php $_SERVER[PHP_SELF]; ?>" method="post">
          <div id="upgrade_form">
         <?php
           global $wpdb, $price_table_name;
           $packages = $wpdb->get_results("SELECT * FROM $price_table_name WHERE status=1");
           if ($packages):
             foreach ($packages as $package):
               $valid_to = $package->validity_per;
               if ($valid_to == 'D') $valid_to = __( "Days", 'cc' );
               if ($valid_to == 'M') $valid_to = __( "Months", 'cc' );
               if ($valid_to == 'Y') $valid_to = __( "Years", 'cc' );
        
		       if ($package->package_type == 'pkg_free') continue;
        ?>
            <div class="add__seo add__seo_premium">
              <div class="inline-wrp">
                <input type="checkbox" value="<?php echo $package->package_cost; ?>" name="price_select" id="<?php echo $package->package_type; ?>" class="add__check">
                <span class="ico cake2-ico"></span>
                <label class="big-label" for="<?php echo $package->package_type; ?>">
                  <span class="big-label__title"><?php echo stripslashes(__($package->price_title,'cc')); ?></span>
                  <p><?php echo __( 'Valid Up to :', 'cc' ) .'&nbsp;'. $package->validity .'&nbsp;'. $valid_to . '<br>' . stripslashes(__($package->price_desc, 'cc')); ?></p>
                </label>
                <div class="big-label__option" id="featured">
                  <label>
                    <input type="checkbox" id="feature_h" name="feature_h" class="add__check" value="<?php echo $package->feature_amount; ?>"><?php echo __( 'Feature this listing on homepage', 'cc' ).' (+ <span id="fhome">'.$package->feature_amount.'</span> '.cc_get_option('cc_currency') . ')'; ?>
                  </label>
                  <label>
                    <input type="checkbox" id="feature_c" name="feature_c" class="add__check" value="<?php echo $package->feature_cat_amount; ?>"><?php echo __( 'Feature this listing on category pages', 'cc' ).' (+ <span id="fhome">'.$package->feature_cat_amount.'</span> '.cc_get_option('cc_currency') . ')'; ?>
                  </label>
                  <div class="add__seo-price">
                    <span class="prem-price"><?php echo $package->package_cost.' <sup>'.cc_get_option('cc_currency').'</sup>'; ?></span>
                    <span class="label-prem">Преміум</span>
                  </div>
                </div>
              </div>
            </div>
			
            <?php endforeach; endif; ?>

            <div class="form_row">
              <div class="label">&nbsp;</div>
              <div class="field">
                <span id='loading' style='display:none;'><img src="<?php echo get_stylesheet_directory_uri() . "/img/loading.gif"; ?>" alt='Loading..' /></span>
              </div> 
            </div>

            <div class="form_row">
              <div class="label">
                <label class="label_total"><?php echo __('Total price as per your selection.','cc'); ?></label>
                <span class="total" id="pkg_price">0</span>&nbsp;+&nbsp;<span class = "total" id="feature_price">0</span>&nbsp;=&nbsp;<span class = "total" id="result_price">0</span><?php echo cc_get_option('cc_currency'); ?>
                <input type="hidden" name="total_price" id="total_price" value="0"/>
				<input type="hidden" value="liqpay" id="liqpay_id" name="pay_method" />
				<input type="hidden" id="post_id" name="post_id" value="" />
              </div>
            </div>
			
          </div>

          <div class="input-wrp input-wrp_block">
            <div id="btnpay" class="hide">
              <a href="#0" class="btn btn_green" id="cash">LIQPAY: <?php echo __( 'Оплатити', 'cc' ); ?> (<span></span> грн)</a>
              <div id="pay-logos" class="add__step text-center">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/visa.png" alt="visa" class="img-responsive inline">
              </div>
            </div>
          </div>
		  
        </form>
<!-- Modal Premium End -->

<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/js/package_price.js"></script>
