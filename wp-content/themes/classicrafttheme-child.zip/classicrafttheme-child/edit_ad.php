<?php

  $pid = $_REQUEST['pid'];
  global $wpdb, $user_ID, $post;
  $update_msg = '';

  $post_obj = get_post( $pid );

  if (isset($_POST['update'])) {
    $fields = array(
	  'cc_title',
	  'cc_description',
	  'cc_category',
	  'cc_price',
    'cc_price_type',
    'cc_state',
	  'custom-price',
      'cc_address_list',
	  'cc_city_id',
      'img1',
      'img2',
      'img3',
    );

    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            $posted[$field] = stripcslashes(trim($_POST[$field]));
        }
    }
    
	$category = array_map('intval', explode(',', $posted['cc_category']));

    //$post_status = "pending";
    $post_status = "publish";
    $cc_my_post['ID'] = $pid;
    $cc_my_post['post_title'] = esc_attr($posted['cc_title']);
    $cc_my_post['post_content'] = $posted['cc_description'];
    $cc_my_post['post_status'] = $post_status;
    $cc_my_post['post_author'] = $user_ID;
    $cc_my_post['post_type'] = POST_TYPE;
    $cc_my_post['post_category'] = $category;

    wp_update_post($cc_my_post);
    //set the categories and tags
    wp_set_object_terms($pid, $category, $taxonomy = CUSTOM_CAT_TYPE);

    update_post_meta( $pid, 'cc_address_list', $posted['cc_address_list'] );
	  update_post_meta( $pid, 'cc_city_id', $posted['cc_city_id'] );

    update_post_meta( $pid, 'cc_state', $posted['cc_state'] );
	
	if( !$posted['img1'] ) {
	  $img_url = get_post_meta( $pid, 'img1', true);
	  if( $img_url ) delete_images( $img_url );
	}
	if( !$posted['img2'] ) {
	  $img_url = get_post_meta( $pid, 'img2', true);
	  if( $img_url ) delete_images( $img_url );
	}
	if( !$posted['img3'] ) {
	  $img_url = get_post_meta( $pid, 'img3', true);
	  if( $img_url ) delete_images( $img_url );
	}
	
	update_post_meta( $pid, 'img1', $posted['img1'] );
    update_post_meta( $pid, 'img2', $posted['img2'] );
	update_post_meta( $pid, 'img3', $posted['img3'] );
	
	if( !$posted['img1'] && $posted['img2'] ) {
      update_post_meta($pid, 'img1', $posted['img2']);
	  update_post_meta($pid, 'img2', '');
    }
			  
	if( !$posted['img1'] && !$posted['img2'] && $posted['img3'] ) {
	  update_post_meta($pid, 'img1', $posted['img3']);
	  update_post_meta($pid, 'img3', '');
	}
			  
    if( isset($posted['custom-price']) ) {
      update_post_meta($pid, 'custom-price', $posted['custom-price']);
      update_post_meta($pid, 'cc_price', '');
      update_post_meta($pid, 'cc_price_type', '');
	}
    else {
	  update_post_meta($pid, 'custom-price', '');
	  update_post_meta($pid, 'cc_price', $posted['cc_price']);
      update_post_meta($pid, 'cc_price_type', $posted['cc_price_type']);
  }
	
    $update_msg = __( "Your ad has been updated.", 'cc' );
}

  if (isset($_POST['update']) && isset($_REQUEST['pay_method']) && $_REQUEST['pay_method'] != '' && $_POST['total_price'] > 0)
  {
    $post_id = $pid;
	$post_title = $cc_my_post['post_title'];
	
    //$post_status = 'pending';
    $post_status = 'publish';

    //Updating expiry table
    if ($_POST['package_validity'] != '' && $_POST['package_validity_per'] != '') {
        global $wpdb, $expiry_tbl_name;
        $validity = $_POST['package_validity'];
        $validity_per = $_POST['package_validity_per'];
        $pkg_type = $_POST['package_type'];
        if ($pkg_type == '') {
            $pkg_type = 'pkg_free';
        }
    }
    
	$featured_home = isset( $_POST['feature_h'] ) ? 'on' : '';
	$featured_cate = isset( $_POST['feature_c'] ) ? 'on' : '';

      if( file_exists(get_stylesheet_directory().'/gateways/liqpay/liqpay.php' ))
        include_once( get_stylesheet_directory().'/gateways/liqpay/liqpay.php' );
  }

  $post_type = POST_TYPE;
  $sql = "SELECT * FROM $wpdb->posts WHERE post_type = '$post_type' AND ID = {$pid}";
  $ad = $wpdb->get_row($sql);

  require_once( get_stylesheet_directory().'/js/ad_field_validation.php' );
?>

<div class="add__title">Редагувати оголошення</div>

<div>
    <?php if ($update_msg) { ?>
    
     <div class="notification mess-info mess-info_center">
            <div class="upload__control-img close-mess">
                <div class="upload__control-del ">
                    <a href="#0">
                            <svg fill="#FFFFFF" height="30" viewBox="0 0 24 24" width="30" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
                                <path d="M0 0h24v24H0z" fill="none"/>
                            </svg>
                    </a>
                </div>
            </div>
            <?php echo $update_msg; ?>
        </div> 
    <?php } ?>

    <form name="edit_post_form" id="edit_post_form" method="post" enctype="multipart/form-data">
    <div class="add__step add__step__container">  
    <div class="input-wrp input-wrp_block add__block">    
          <div class="form__title req">Назва оголошення</div>
          <div class="input-wrp input-wrp_block">
              <span class="max-text">Максимум 100 символів</span>
              <input type="text" id="title" class="input_add" name="cc_title" placeholder="Введіть назву" value="<?php echo $ad->post_title; ?>" />
          </div>
      </div>

      <div class="input-wrp input-wrp_block add__block">                            
                                <div class="col6 nopaddingl">
                                    <div class="req form__title">Оберіть категорію</div>                                        
                                    <span class="cats_error"></span>
                                    <div id="ad-categories">
                                    <?php
                                          $cat_objs = $cats = array();
                                          $cat_objs = wp_get_post_terms($pid, CUSTOM_CAT_TYPE);
                                          foreach( $cat_objs as $cat_obj ){
                                            $cats[] = $cat_obj->term_id;
                                          }
                                  
                                  $taste_terms = get_terms(array( 'taxonomy' => 'cate', 'child_of' => 101 ));
                                  foreach( $taste_terms as $term ) $taste_ids[] = $term->term_id;

                                  $event_terms = get_terms(array( 'taxonomy' => 'cate', 'child_of' => 100 ));
                                  foreach( $event_terms as $term ) $event_ids[] = $term->term_id;
                                  
                                  $terms = get_terms(array( 'taxonomy' => 'cate' ));
                                          foreach( $terms as $term ) {
                                    if( !in_array( $term->term_id, $taste_ids ) && !in_array( $term->term_id, $event_ids )) {
                                    if( $term->parent ) $child_ids[] = $term->term_id;
                                    else $ids[] = $term->term_id;
                                    }
                                  }

                                  $id = array_shift( array_intersect( $ids, $cats ));
                                  $child_id = array_shift( array_intersect( $child_ids, $cats ));
                                  $taste_id = array_shift( array_intersect( $taste_ids, $cats ));
                                  $event_id = array_shift( array_intersect( $event_ids, $cats ));
                                        ?>
                                    <div class="input-wrp input-wrp_block ">
                                      <?php my_dropdown_categories( 'maincat', 'Категорія', 0, $id  ); ?>
                                    </div>
                                    </div>
                                    <input id="chosenCategory" name="cc_category" type="hidden" value="" />
                                </div>
                                <div class="col6 nopaddingr">
                                    <div class="req form__title">Стан</div>
                                    <div class="input-wrp input-wrp_block ">
                                        <select name="cc_state" class="input_add">
                                        <option value="new" <?php if( get_post_meta($pid, 'cc_state', true)=='new' ) echo 'selected'; ?>>Нове</option>
                                        <option value="used" <?php if( get_post_meta($pid, 'cc_state', true)=='used' ) echo 'selected'; ?>>Вживане</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

          <div class="input-wrp input-wrp_block add__block" id="price-block">
                                <div class="col6 nopaddingl">
                                    <div class="req form__title">Ціна, грн</div>
                                    <div class="input-wrp input-wrp_block">
                                        <input type="number" type="text" class="input_add" placeholder="Введіть ціну" min="1" max="999" id="cc_price" name="cc_price"  value="<?php echo get_post_meta($pid, 'cc_price', true); ?>" />
                                    </div>
                                </div>
                                <div class="col6 nopaddingr">
                                    <div class="req form__title">Ціна за</div>
                                    <div class="input-wrp input-wrp_block">
                                        <select name="cc_price_type" class="input_add">
                                          <option value="hour" <?php if( get_post_meta($pid, 'cc_price_type', true)=='hour' ) echo 'selected'; ?>>Годину</option>
                                          <option value="day" <?php if( get_post_meta($pid, 'cc_price_type', true)=='day' ) echo 'selected'; ?>>День</option>
                                          <option value="service" <?php if( get_post_meta($pid, 'cc_price_type', true)=='service' ) echo 'selected'; ?>>Послугу</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
        <div class="add__block">
                              <label>
                                  <input type="checkbox" class="add__check" value="1" name="custom-price" id="custom-price" <?php if( get_post_meta($pid, 'custom-price', true) ) echo 'checked="checked"'; ?>>Ціна за домовленістю
                              </label>
                            </div>
    
        <div class="req form__title">Опис оголошення</div>
        <div class="input-wrp input-wrp_block">
        <span class="max-text">Максимум 1000 символів</span>
          <span class="desc_error"></span>
            <textarea id="cc_desc" class="textarea textarea_mess" name="cc_description"><?php echo $ad->post_content; ?></textarea>
        </div>
      </div>
        <div class="add add__step add__step__container">
                        <div class="step__title">Додати зображення</div>
                        <span class="photo_error"></span>
						<?php $id1 = "img1"; $id2 = "img2"; $id3 = "img3"; ?>

                        <div class="add__photo-grid-container">
					    <div class="add__upload_big ">
                            <div class="upload_img-wrp">
                                <div class="add__upload">
                                    <div class="add__upload-text">
                                        <div class="div add__photo-title">Завантажте фото</div>
                                        <p>Завантажте фото своєї техніки у галерею. Пам'ятайте, що чим краще картинка - тим більше людей звернуть увагу на Ваше оголошення.</p>
                                        <?php my_photo_markup( $id1, get_post_meta( $pid, $id1, true )); ?>
                                    </div>
                                </div>
								<div class="plupload-thumbs hide" id="<?php echo $id1; ?>plupload-thumbs">
                                </div>
                            </div>
                        </div>

                            <div class="small-top">
                                <div class="upload_img-wrp">
                                <?php my_photo_markup( $id2, get_post_meta( $pid, $id2, true ) ); ?>
                                  <div class="plupload-thumbs hide" id="<?php echo $id2; ?>plupload-thumbs">
                                  </div>
                                </div>
                            </div>

                            <div class="small-bot">
                                <div class="upload_img-wrp">
                                <?php my_photo_markup( $id3, get_post_meta( $pid, $id3, true ) ); ?>
                                  <div class="plupload-thumbs hide" id="<?php echo $id3; ?>plupload-thumbs">
                                  </div>
                                </div>
                            </div>
                        </div>

      </div>
       
        <div class="add__form-item_contact add__step add__step__container">
                            <div class="step__title">Де знаходиться техніка?</div>                            
							<div id='address_list'></div>                            
                            <div class="req form__title">Вкажіть адресу</div>
                            <div class="input-wrp input-wrp_block">
								<span class="max-text">Максимум 4 адреси</span>
								<input type="hidden" name="cc_address_list" id="cc_address_list" value='<?php echo get_post_meta($pid, 'cc_address_list', true); ?>' />
                                <input type="hidden" name="cc_city_id" id="cc_city_id" value='<?php echo get_post_meta($pid, 'cc_city_id', true); ?>'/>
                                <div class="address-input__container">
                                    <input type="text" name="cc_address" id="cc_address" class="input_add noEnterSubmit" value='' placeholder="Адреса" />
                                    <input type="button" id="add_address" value="Додати" />
                                </div>
			                    <div id="map_canvas" style="height:350px; margin-top: 10px; position:relative;"  class="form_row clearfix"></div>
			                    <?php edit_map(); ?>
                            </div>
                        </div>
        
     <div class="add__step__container last__step__margin">
                        <?php if( get_post_meta( $ad->ID, 'cc_add_type', true ) == 'free' ) : ?>
                        <!--Start Row--> 
                        <div class="input-wrp input-wrp_block">
                            <div class="label">
                                <!-- <label class="label_update"><?php echo __( 'Want to Upgrade your Listing to Premium ?','cc'); ?></label> -->
                            </div>
                            <div class="input-wrp input-wrp_block">                                            
                                <label><input type="checkbox" class= "add__check" id="be_paid" name="be_paid" />Зробити Преміум</label> <br/>
                            </div>
                        </div>
                        <!--End Row-->
                    <?php endif; ?>
                  
                    <div style="display:none;" id="upgrade_form">
                  
                    <script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/js/package_price.js"></script>
                      <script type="text/javascript">
                        jQuery(document).ready(function(){
                          jQuery('input:checkbox[name=be_paid]').prop('checked', false).trigger('refresh');
                            jQuery('input:checkbox[name=be_paid]').change(function(){  
                
                                if(this.checked){
                                    jQuery("#upgrade_form").slideDown();
                                } 
                                else{
                                    jQuery("#upgrade_form").slideUp();
                                }
                            });         
                                                                          
                        });
                      </script>
                  <?php
                    
                    global $wpdb, $price_table_name;
                    $packages = $wpdb->get_results("SELECT * FROM $price_table_name WHERE status=1");
                    if ($packages):
                      foreach ($packages as $package):
                        $valid_to = $package->validity_per;
                        if ($valid_to == 'D') $valid_to = __( "днів", 'cc' );
                        if ($valid_to == 'M') $valid_to = __( "місяців", 'cc' );
                        if ($valid_to == 'Y') $valid_to = __( "років", 'cc' );
                        
                    if ($package->package_type == 'pkg_free') continue;
                  ?>
                          <div class="add__seo">
                            <div class="inline-wrp">
                              <input type="checkbox" value="<?php echo $package->package_cost; ?>" name="price_select" id="<?php echo $package->package_type; ?>" class="add__check">
                              <input type="hidden" class="<?php echo $package->package_type; ?>" name="<?php echo $package->package_type; ?>" value="<?php echo $package->validity; ?>"/>
                              <input type="hidden" class="<?php echo $package->package_type_period; ?>" name="<?php echo $package->package_type_period; ?>" value="<?php echo $package->validity_per; ?>"/>
                              <input type="hidden" class="is_recurring" name="is_recurring" value="<?php echo $package->is_recurring; ?>"/>
                              <input type="hidden" class="validity" name="validity" value="<?php echo $package->validity; ?>"/>
                              <input type="hidden" class="validity_per" name="validity_per" value="<?php echo $package->validity_per; ?>"/>
                              <input type="hidden" class="pkg_type" name="pkg_type" value="<?php echo $package->package_type; ?>"/>
                              <input type="hidden" class="is_featured" name="is_featured" value="<?php echo $package->is_featured; ?>"/>                            
                              <input type="hidden" id="price_title" name="price_title" value="<?php echo $package->price_title; ?>"/>
                        
                              <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/crown.svg" class="add__seo__icon" />
                        
                              <label class="big-label" for="<?php echo $package->package_type; ?>">
                                <span class="big-label__title"><?php echo stripslashes(__($package->price_title,'cc')); ?></span>
                                <p><?php echo __( 'Термін дії :', 'cc' ) .'&nbsp;'. $package->validity .'&nbsp;'. $valid_to . '<br>' . stripslashes(__($package->price_desc, 'cc')); ?></p>
                              </label>
                              <div class="add__seo__price">
                                  <?php echo $package->package_cost; ?> грн
                                </div>
                                <div class="big-label__option" id="featured">
                                <label>
							        <input type="checkbox" id="feature_h" name="feature_h" class="add__check" value="<?php echo $package->feature_amount; ?>"><?php echo __( 'Відображати як преміум на головній сторінці сайту', 'cc' ).' <b>+<span id="fhome">'.$package->feature_amount.'</span> '.cc_get_option('cc_currency').'</b>'; ?>
								</label>
                                <label>
                                    <input type="checkbox" id="feature_c" name="feature_c" class="add__check" value="<?php echo $package->feature_cat_amount; ?>"><?php echo __( 'Відображати як преміум на сторінці категорії', 'cc' ).' <b>+<span id="fhome">'.$package->feature_cat_amount.'</span> '.cc_get_option('cc_currency').'</b>'; ?>
								</label>
                            </div>
                            </div>
                          </div>
                      
                          <?php endforeach; endif; ?>
                
                            <div class="form_row">
                              <div class="label">
                                <input type="hidden" name="total_price" id="total_price" value="0"/>  
                                <input type="hidden" name="package_title" id="package_title" value=""/>
                                <input type="hidden" name="package_validity" id="package_validity" value=""/>
                                <input type="hidden" name="package_validity_per" id="package_validity_per" value=""/>
                                <input type="hidden" name="package_type" id="package_type" value=""/>
                              </div>
                            </div>
                          </div>
                
                          <div class="input-wrp input-wrp_block">
                        <div id="btnsend" class="btnsend">
                          <a href="#0" class="btn btn_lblue" id="update">Оновити</a>
                        <input type="button" class="btn btn_lblue btn_cancel" onclick="window.location.href='<?php echo CC_DASHBOARD ?>'" value="Скасувати" />
                      </div>
                      <div id="btnpay" class="hide">
                              <a href="#0" class="btn btn_green" id="cash">LIQPAY: Оплатити (<span></span> грн)</a>
                        <input type="button" class="btn btn_lblue btn_cancel" onclick="window.location.href='<?php echo CC_DASHBOARD ?>'" value="Скасувати" />
                              <div id="pay-logos" class="add__step text-center">
                                <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/visa.png" alt="visa" class="img-responsive inline">
                              </div>
                            </div>
                          </div>
                      
                      <input type="hidden" name="update" value="" />
                      
                      <ul id="payments">
                            <li id="liqpay">
                              <label class="r_lbl"><input  type="hidden" value="liqpay" id="liqpay_id" name="pay_method" checked="checked" /></label>
                            </li>
                          </ul>
                      </div>
	  
    </form>
      </div>
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/js/placeholder.min.js"></script>
<script type="text/javascript">
    tinymce.init({
        selector: 'textarea',
        height: 300,
        menubar: false,
        plugins: ["lists", "placeholder"],
        toolbar: 'undo redo |  formatselect | bold italic backcolor  | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
        });
</script>