<?php
/**
 * The template for displaying Author Archive pages.
 *
 *
 */
    //This sets the $curauth variable
    if (isset($_GET['author_name'])) :
        $curauth = get_user_by('login', $author_name);
    else :
        $curauth = get_userdata(intval($author));
    endif;
	
	$skype = get_the_author_meta('skype', $curauth->ID);
	$awards = get_the_author_meta( 'awards', $curauth->ID );
	$ava = get_the_author_meta( 'user_avatar', $curauth->ID );
	if( !$ava ) $ava = get_stylesheet_directory_uri() .'/img/no-avatar.png';
   
    get_header();
?>
<div class="container">
<section>
    <div class="container">
        <div class="author author_grid">
            <div class="author__title author__title_grid">
                <div class="col6">
                    <div class="author__img">
					   <img alt="" src="<?php echo $ava; ?>" />
                    </div>
                </div>
                <div class=" col6">
                    <div class="author__name ">
                        <?php echo $curauth->nickname; ?>
						<span id="city"></span>
			            <input type="hidden" name="cc_city_id" id="cc_city_id" class="input input_add" value="<?php echo get_the_author_meta('city_id', $curauth->ID); ?>" />
                    </div>
                </div>

            </div>
            <div class="author__contact author__contact_grid">
                <div class="col6">
                    <div class="author__tel">
                        <?php echo get_the_author_meta('phone', $curauth->ID); ?>
                    </div>
                    <ul class="author__web">
                        <li><a href="<?php echo get_the_author_meta('url', $curauth->ID); ?>"><?php echo get_the_author_meta('url', $curauth->ID); ?></a></li>
                        <li><?php echo get_the_author_meta('user_email', $curauth->ID); ?></li>
                    </ul>
                </div>
                <div class="col6">
				    <?php if( $skype ) : ?>
                    <a href="#0" class="author__skype"><i class="fa fa-skype"> </i><?php echo $skype; ?></a>
				    <?php endif; ?>
                    <!--<a  href="#0" class="author__chat"><span class="ico chat2-ico"></span> <?php echo __( 'Write to manufacturer', 'cc' ); ?></a>-->
                </div>
            </div>
            <div class="author__about">
                <h3><?php echo __( 'About me', 'cc' ); ?></h3>
                <p><?php
				  $desc = nl2br(get_the_author_meta('description', $curauth->ID));
				  if( $desc ) echo $desc;
				  else echo __( 'No description available', 'cc' );
				?></p>
            </div>
			
			<?php if( $awards ) : ?>
			<div class="author__about">
			  <h3><?php echo __( 'Benefits', 'cc' ); ?></h3>
			  <p>
			    <ul class="author-side__award-wrp">
				<?php
				  $benefits = benefits_info();
			      $awards = explode(",", $awards);
			      for( $i=0; $i<$benefits['num']; $i++ ) {
				    foreach( $awards as $award )
				      if( $award == $benefits['slug'][$i] ) {
					    echo '
				  <li class="author-side__award">
				    <a href="'.$benefits['url'][$i].'" title="'. __( $benefits['name'][$i],'cc' ) .'">
					  <img src="'. get_stylesheet_directory_uri() .'/img/award-'.$benefits['slug'][$i].'.png" alt="'. __( $benefits['name'][$i],'cc' ) .'">
					</a>
				  </li>';
				    }
			      }
			    ?>
                </ul>
			  </p>
			</div>
			<?php endif; ?>
			
			<?php
              query_posts(array(
                'post_type' => POST_TYPE,
                'posts_per_page' => -1,
                'author' => $curauth->ID
              ));
              if (have_posts()) :
		    ?>
			
            <div class="author__adv">
                <h3><?php echo __( 'Manufacturer ads', 'cc' ); ?></h3>
				
				<?php while (have_posts()): the_post(); ?>
				
                <div class="cat-item">
                    <div class="product-item">
					
                        <div class="product-item__img">
                            <?php echo ad_thumbnail(); ?>
                        </div>
						
                        <div class="product-item__title">
                            <a href="<?php the_permalink() ?>" class="link product-item__title">
							  <?php echo title_excerpt(); ?>
							</a> <?php echo __( 'from', 'cc' ); ?>
							<?php echo the_author_posts_link(); ?>
                        </div>
						
                        <?php echo price_output(); ?>
						
                    </div>
                </div>
				<?php endwhile; ?>
            </div>
			
			<?php endif; wp_reset_query(); ?>
        </div>
    </div>
</section>
</div>
<?php get_footer(); ?>