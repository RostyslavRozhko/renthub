<div id="myModal" class="modal-wind">
  <!-- Modal content -->
  <div class="modal modal-wrap modal_login">
   <!--  <span class="close close_modal"><i class="fa fa-close"></i></span> -->
    <div class="modal__header modal__header_login">
     <div class="upload__control-img">
                                    <div class="upload__control-del">
                                        <a href="#0">
                                            <svg fill="#FFFFFF" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
                                                <path d="M0 0h24v24H0z" fill="none"/>
                                            </svg>
                                        </a>
                                    </div>
                                </div>
      <img src="<?php if (cc_get_option('cc_logo') != '') { ?><?php echo cc_get_option('cc_logo'); ?><?php } else { ?><?php echo get_template_directory_uri(); ?>/images/logo.png<?php } ?>" alt="<?php bloginfo('name'); ?>" />
    </div>
    <div class="modal__tabs">
      <a href="#tab2" class="modal-tab login__item login__item_modal link">Реєстрація</a>
      <a href="#tab1" class="modal-tab login__item login__item_modal link link_active">Вхід</a>
    </div>
    <div class="modal__body">
      <div class="modal__login active-tab" id="tab1">
       
		<!-- Click here to login or register with Facebook -->
        <form id="login" class="form form_modal-login" action="login" method="post">
<!--<h3>New to site? <a id="pop_signup" href="">Create an Account</a></h3>-->
          <p class="status"></p>  
          <?php wp_nonce_field('ajax-login-nonce', 'security'); ?>  
          <div class="modal__input-container">
            <input type="text" name="email" id="email" class="required email input input_modal modal__input__top" placeholder="Email">
            <input type="password" name="password" id="password" class="required input input_modal modal__input__bottom modal__input_border " placeholder="Пароль">
          </div>
          <a class="text-link modal__btn__forgot" href="<?php echo home_url('restore-password'); ?>">Забули пароль?</a>          
          <input class="submit_button btn btn_modal modal__btn modal__btn__login" type="submit" name="login" value="Ввійти в особистий кабінет"/>
          <div class="text-center">
          <a  href="<?php echo home_url() ?>/wp-login.php?loginFacebook=1&redirect=<?php echo home_url() ?>" onclick="window.location = '<?php echo home_url() ?>/wp-login.php?loginFacebook=1&redirect=<?php echo home_url() ?>/dashboard/'; return false;">
            <div class="modal__btn modal__btn__facebook">
              <div class="modal__btn__text">Увійти з Facebook</div>
            </div>
          </a>
        </div>
        </form>

		<!--
<form id="forgot_password" class="ajax-auth" action="forgot_password" method="post">
    <div class="modal__title">
      <?php echo __( 'Forgot Password', 'cc' ); ?>
    </div>
    <p class="status"></p>
    <?php wp_nonce_field('ajax-forgot-nonce', 'forgotsecurity'); ?>
    <label for="user_login">E-mail</label>
    <input id="user_login" type="text" name="user_login">
    <input class="submit_button" type="submit" value="SUBMIT">
</form>
		-->
      </div>
      <div class="hide modal__sign-in" id="tab2">
        <form id="registration" class="form form_modal-login"  action="register" method="post">
<!--<h3>Already have an account? <a id="pop_login"  href="">Login</a></h3>-->
          <p class="status"></p>
          <?php wp_nonce_field('ajax-register-nonce', 'signonsecurity'); ?>         
          <input id="nick" type="text" class="required input input_modal modal__input__top" name="nick" placeholder="Ім'я">
          <input id="emailreg" type="text" class="required email input input_modal" name="email" placeholder="Email">
          <input id="signonpassword" type="password" class="required input input_modal modal__input__bottom" name="signonpassword" placeholder="Пароль">
          <!-- <input type="password" id="password2" class="required input input_modal" name="password2" placeholder="<?php echo __( 'Password again', 'cc' ); ?>"> -->
	
	      <?php if (cc_get_option('reg_terms') == 'on') { $lang = pll_current_language() != 'uk' ? '-'.pll_current_language() : ''; ?>
	      <div class="form__option">
	        <input type="checkbox" id="terms" name="terms"/>
		    <?php echo sprintf(__("Я погоджуюсь з правилами користування", 'cc'), add_query_arg( 'lang', false, home_url('terms'.$lang.'/'))); ?>
            <span style="display:block;" class="term_error"></span>
          </div>
          <?php } ?>

          <input class="submit_button btn btn_modal modal__btn modal__btn__login" type="submit" value="Створити обліковий запис" tabindex="103">

           <div class="text-center">
          <a href="http://sweetico.com/wp-login.php?loginFacebook=1&redirect=<?php echo home_url() ?>" onclick="window.location = '<?php echo home_url() ?>/wp-login.php?loginFacebook=1&redirect=<?php echo home_url() ?>/dashboard/'; return false;">
            <div class="modal__btn modal__btn__facebook">
              <div class="modal__btn__text">Увійти з Facebook</div>
            </div>
          </a>
        </div>

        </form>
      </div>
    </div>
  </div>
</div>