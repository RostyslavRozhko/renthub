<?php get_header(); ?>

<div class="container">
  <div class="not-found-flex">
    <img class="not-found__icon" src="<?php echo get_stylesheet_directory_uri(); ?>/img/tractor.svg" />
    <div class="not-found__text-top">Нічого не знайдено</div>
    <div class="not-found__text-bot">Нам шкода, але на Prokkat немає жодного оголошення,</br>
яке відповідає Вашому запиту.</div>
    <a href="<?php echo home_url(); ?>" class="not-found__link">Перейти на головну</a>
  </div>
</div>

<?php get_footer(); ?>