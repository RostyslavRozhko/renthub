<?php
/**
 * Template Name: Template Blog
 */
get_header();
?>
<!--Start Cotent Wrapper-->
<div>
    <div class="container">
        <div>
            <div>
                <!--Start Cotent-->
                <div class="content">
                    <?php
                    $limit = get_option('posts_per_page');
                    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
					query_posts(array(
                     'post_type' => 'post',
                     'posts_per_page' => $limit,
                     'paged' => $paged
                   ));
                    $wp_query->is_archive = true;
                    $wp_query->is_home = false;
                    ?>
                    <?php get_template_part('loop', 'blog'); ?>
                    <?php cc_pagination(); ?>
                    <div class="clear"></div>
                </div>
                <!--End Cotent-->
            </div>
            <div class="grid_7 omega">
                <div class="sidebar">
                    <?php
                    if (is_active_sidebar('pages-widget-area')) :
                        dynamic_sidebar('pages-widget-area');
                    endif;
                    ?>
                </div>
            </div>
        </div>
        <div class="clear"></div>
    </div>
</div>
<!--End Cotent Wrapper-->
<?php get_footer(); ?>