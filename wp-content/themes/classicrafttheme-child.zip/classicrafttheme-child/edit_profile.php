<?php
global $current_user;
$status = false;
$update_msg = $err_msg = $user_data = '';

  if (isset($_POST['edit_profile'])) {

    $user_meta = $wp_user = array();
	
	if( isset( $_POST['nname'] ) && $_POST['nname'] ) {
	  $user_meta['nickname'] = $wp_user['display_name'] = esc_attr($_POST['nname']);
	}
	$user_meta['city_id'] = isset( $_POST['cc_city_id'] ) ? esc_attr($_POST['cc_city_id']) : '';
    $user_meta['skype'] = isset( $_POST['skype'] ) ? esc_attr($_POST['skype']) : '';
    $user_meta['phone'] = isset( $_POST['phone'] ) ? esc_attr($_POST['phone']) : '';
    $user_meta['description'] = isset( $_POST['abtme'] ) ? esc_attr($_POST['abtme']) : '';
    $user_meta['description_ru'] = $user_meta['description'];
	
    //Update user data
    foreach ($user_meta as $meta_key => $meta_value):
        update_user_meta( $current_user->ID, $meta_key, $meta_value );
    endforeach;
	
	$wp_user['user_email'] = esc_attr($_POST['email']);
    $wp_user['user_url'] = esc_attr($_POST['website']);
	
	foreach ($wp_user as $meta_key => $meta_value):
        if ( $meta_key == 'user_email' && $meta_value == '' ) continue;
		$user_data = wp_update_user( array( 'ID' => $current_user->ID, $meta_key => $meta_value ) );
		if ( is_wp_error( $user_data ) ) {
          $err_msg = $user_data->get_error_message();
        }
    endforeach;

	if( !$err_msg ) $update_msg = "Ваш профіль оновлено";

  }

  if( $err_msg ){ echo '<p class="error">'. $err_msg .'</p>'; }
  
  if( isset( $_GET['activated'] ) && $_GET['activated']=='yes' ) : ?>
     <div class="mess-info">
       <div class="upload__control-img close-mess">
         <div class="upload__control-del ">
           <a href="#0">
             <svg fill="#FFFFFF" height="30" viewBox="0 0 24 24" width="30" xmlns="http://www.w3.org/2000/svg">
               <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
               <path d="M0 0h24v24H0z" fill="none"/>
             </svg>
           </a>
         </div>
       </div>
       <div class="mess-info__title">
         <?php echo __('Welcome to Sweetico!', 'cc'); ?>
       </div>
       <p>
         <?php echo __('You signed up as a manufacturer, so you can add ads with your sweets.<br />Our visitors will become your regular customers.', 'cc'); ?>
       </p>
     </div>
  <?php endif; ?>
	
  <div class="add__title">Редагувати профіль</div>
  <?php if ($update_msg) { ?>
    
     <div class="notification mess-info mess-info_center">
            <div class="upload__control-img close-mess">
                <div class="upload__control-del ">
                    <a href="#0">
                            <svg fill="#FFFFFF" height="30" viewBox="0 0 24 24" width="30" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
                                <path d="M0 0h24v24H0z" fill="none"/>
                            </svg>
                    </a>
                </div>
            </div>
            <?php echo $update_msg; ?>
        </div> 
    <?php } ?>
  <div>
    <form name="edit_profile_form" id="edit-profile-form" method="post" enctype="multipart/form-data">
    <div class="add__step__container last__step__margin">  
        <div class="input-wrp input-wrp_block add__block">
            <div class="form__title">Назва оголошення</div>
            <div class="input-wrp input-wrp_block">
                <input type="text" class = "input_add" id="nname" name="nname" value="<?php echo get_the_author_meta('nickname', $current_user->ID); ?>"/>
            </div>
        </div>

        <div class="input-wrp input-wrp_block add__block">
                                <div class="col6 nopaddingl">
                                    <div class="form__title">Місто</div>
                                    <div class="input-wrp input-wrp_block">
                                        <input type="text" name="cc_address" id="cc_address" class="input_add noEnterSubmit" value="" placeholder="Почніть вводити назву міста" />
                                        <input type="hidden" name="cc_city_id" id="cc_city_id" class="input_add" value="<?php echo get_the_author_meta('city_id', $current_user->ID); ?>" />
                                        <div id="map_canvas" style="height:350px; margin-top: 10px; position:relative;"  class="form_row clearfix hide"></div>
                                        <?php edit_map(); ?>
                                    </div>
                                </div>
                                <div class="col6 nopaddingr">
                                    <div class="form__title">Email</div>
                                    <div class="input-wrp input-wrp_block">
                                        <input type="text" class = "input_add" id="email" name="email" value="<?php echo get_the_author_meta('user_email', $current_user->ID); ?>"/>
                                    </div>
                                </div>
                            </div>
        <div class="input-wrp input-wrp_block add__block">
            <div class="col6 nopaddingl">
                <div class="form__title">Телефон</div>
                <div class="input-wrp input-wrp_block">
                    <input type="tel" class="input_add" id="phone" name="phone" value="<?php echo get_the_author_meta('phone', $current_user->ID); ?>" />
                </div>
            </div>
            <div class="col6 nopaddingr">
                <div class="form__title">Skype</div>
                <div class="input-wrp input-wrp_block">
                    <input type="text" class = "input_add" id="skype" name="skype" value="<?php echo get_the_author_meta('skype', $current_user->ID); ?>"/>
                </div>
            </div>
        </div>
        <div class="form__title">Про мене</div>
        <div class="input-wrp input-wrp_block">
            <textarea id="abtme" class ="textarea textarea_mess textarea_chat" name="abtme"><?php echo get_the_author_meta('description', $current_user->ID); ?></textarea>
        </div>
        <div class="input-wrp_block text-right">
            <input type="submit" class = "save-btn" name="edit_profile" value="Зберегти" />
        </div>
    <div>
    </form>
</div>

<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/jquery.maskedinput.min.js"></script>
<script>
jQuery(document).ready(function(){
  $('#phone').mask("+38 (999) 999-99-99");
});
</script>