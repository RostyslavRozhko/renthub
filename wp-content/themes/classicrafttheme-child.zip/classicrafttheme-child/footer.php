<footer class="footer">
    <section>
        <div class="container">
            <div class="top-nav bot-nav">
                   <a class="logo" href="<?php echo home_url(); ?>"><img src="<?php if (cc_get_option('cc_logo') != '') { ?><?php echo cc_get_option('cc_logo'); ?><?php } else { ?><?php echo get_template_directory_uri(); ?>/images/logo.png<?php } ?>" alt="Budico" class="img-responsive fleft" /></a>
                    
                <div class="footer__left">
                    <a href="<?php echo home_url('ad-new/'); ?>" class="login__item login__item__yellow">
                    <i class="fa fa-plus" aria-hidden="true"></i>
                        Подати оголошення
                    </a>
                </div>
                        
											   
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="footer__cat">
        <div class="container">
            <div class="footer_padding footer__flex">
                <div class="footer__cat__title">Люди шукають</div>
                <div class="footer__cat__container">
                    <?php
                        $categories = get_categories(array(
                            'taxonomy' => 'cate',
                            'hide_empty' => false,
                            'parent'=>0,
                        ));
                        foreach ( $categories as $category )
                            echo '
                            <div class="footer__cat__link-container"><a href="'.esc_url( get_category_link( $category->term_id ) ).'" class="footer__cat__link">'.esc_html( $category->name ).'</a></div>';
                    ?>
                </div> 
            </div>
        </div>
    </section>
    <section class="footer__menu">
        <div class="container">
            <div class="footer_padding">
                <div class="footer__column store-btn__container">
                    <div class="store-btn">
                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/apple.svg" class="store-icon" />
                        <div>
                            <div class="store-bnt__text__top">Available in</div>
                            <div class="store-bnt__text__bottom">App store</div>
                        </div>
                    </div>
                    <div class="store-btn">
                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/play-store.svg" class="store-icon" />
                        <div>
                            <div class="store-bnt__text__top">Available in</div>
                            <div class="store-bnt__text__bottom">Google Play</div>
                        </div>
                    </div>
                </div>   
                <div class="footer__column">
                <div class="footer__column-text bold">Покупцям</div>
                <a class="footer__column-text" >Як орендувати техніку?</a>
                <a class="footer__column-text" >Як захиститись від шахраїв?</a>
                <a class="footer__column-text" >Відгуки</a>
                </div>
                <div class="footer__column">
                    <div class="footer__column-text bold column-bigger">Продавцям</div>
                    <a class="footer__column-text" >Як подати оголошення?</a>
                    <a class="footer__column-text" >Тарифи</a>
                    <a class="footer__column-text" >Політика конфеденційності</a>
                    <a class="footer__column-text" >Правила користування</a>
                </div>
                <div class="footer__column">
                    <div class="footer__column-text bold">Про нас</div>
                    <a class="footer__column-text" >Компанія</a>
                    <a class="footer__column-text" >Робота в Budico</a>
                    <a class="footer__column-text" >Контакти</a>
                    <a class="footer__column-text" >Реклама</a>
                </div>
            </div>
        </div>
    </section>
    <div class="footer__copyright">
        <div class="container">
            <div class="footer__social-icons">
                    <img src="<?php echo get_stylesheet_directory_uri() . "/img/twitter.svg"; ?>" />
                    <img src="<?php echo get_stylesheet_directory_uri() . "/img/facebook-2.svg"; ?>" />
            </div>
            <div class="footer__logo footer__left">Budico.com 2018</div>
        <div>
    </div>
</footer>
<?php map_script(); wp_footer(); ?>
</body>
</html>
