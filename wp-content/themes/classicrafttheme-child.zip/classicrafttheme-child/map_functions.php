<?php

  function map_script()
  {
	global $post; ?>
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDumu-d4N1FXsPcewuVrm4C5y-IZ3eg-5M&libraries=places&language=<?php echo pll_current_language('slug'); ?>"></script>
  
    <script>
      function initMap() {

        var input_search = document.getElementById('s_address');

		var options = {
	      componentRestrictions: {country: 'ua'}
	    };
	    
	    var autocomplete_s = new google.maps.places.Autocomplete(input_search, options);
        
        autocomplete_s.addListener('place_changed', function() {
	      var place_s = autocomplete_s.getPlace();
		  if (typeof place_s.place_id != 'undefined') jQuery('#s_city_id').val(place_s.place_id);
		  jQuery('#s_address').val(place_s.address_components[0].long_name);
        });
		
		<?php if( is_tax('cate') ) : ?>
		
		var input_cat = document.getElementById('cat_address');
		
		var autocomplete_cat = new google.maps.places.Autocomplete(input_cat, options);
		
		autocomplete_cat.addListener('place_changed', function() {
	      var place_cat = autocomplete_cat.getPlace();
		  if (typeof place_cat.place_id != 'undefined') jQuery('#cat_address_link').attr("href", '<?php global $wp; echo add_query_arg( array( 'lang' => false ), home_url( $wp->request )) . '?search_loc='; ?>' + place_cat.place_id + '&city=' + place_cat.address_components[0].long_name+ '&lang=<?php echo pll_current_language(); ?>');
		  jQuery('#cat_address').val(place_cat.address_components[0].long_name);
        });
		
		<?php endif; ?>
		
		<?php if( is_single() ) : ?>
		
		const map = new google.maps.Map(document.getElementById('map_canvas'));
		const geocoder = new google.maps.Geocoder;
		const address_list = document.getElementById('address_list')
		const cc_address_list = document.getElementById('cc_address_list')
		const arr = []
		
		function show() {
		const IDs = JSON.parse(cc_address_list.value)
    	IDs.map(placeId => {
    		geocoder.geocode({'placeId': placeId}, function(results, status) {
              if (status === google.maps.GeocoderStatus.OK) {
                if (results[0]) {
                	const place = results[0]
                  map.setZoom(10);
                  map.setCenter(place.geometry.location);
                  let marker = new google.maps.Marker({
                    map: map,
                    position: place.geometry.location
                  });

                  let city, country, street, street_number
                  place.address_components.map(res => {
                    if (res.types.indexOf('locality') > -1) {
                      city = res.long_name
                    }
                    if (res.types.indexOf('country') > -1) {
                      country = res.long_name
                    }
                    if (res.types.indexOf('route') > -1) {
                      street = res.long_name
                    }
                    if (res.types.indexOf('street_number') > -1) {
                      street_number = res.long_name
                    }
                  })
                  
                  const placeObj = {
                    placeId: placeId,
                    location: place.geometry.location,
                    name: place.formatted_address,
                    city: city,
                    country: country,
                    street: street,
                    street_number: street_number
                  }

                  arr.push({
                  	place: placeObj,
                    marker: marker
                  })
                  
                  showAddress()
                }
              }
            });
		})
				}
			
			function showAddress() {
        	address_list.innerHTML = ''
          
        	arr.map((obj, pos) => {
          	const id = `address_${pos}`
            let street_name = ''
            if(obj.place.street) {
              street_name += obj.place.street

              if(obj.place.street_num) {
                street_name += ", " + obj.place.street_num
              }
            }

            address_list.innerHTML += 
							`
              	<div class="address_container">
                  <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/location-pin.svg" class="location-icon" />
                  <div class="address_container__text">
                    <div class="formated-address__top">${obj.place.city}, ${obj.place.country}</div>
                    <div class="formated-address__bottom">${street_name}</div>
                  </div>
                </div>
              `          	
          })
      }
	  
	  show()

		
		<?php endif; ?>
		
		<?php if( is_author() ) : ?>
		
		var geocoder = new google.maps.Geocoder;
		var placeId = jQuery('#cc_city_id').val();
        geocoder.geocode({'placeId': placeId}, function(results, status) {
          if (status === google.maps.GeocoderStatus.OK) {
            if (results[0]) {
			  jQuery('#city').text('<?php echo __( 'c.', 'cc' ); ?> ' + results[0].address_components[0].long_name);
            }
          }
        });
		
		<?php endif; ?>
      }
	  google.maps.event.addDomListener(window, 'load', initMap);
  </script>
  <?php
  }
  
  function edit_map()
  { ?>
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDumu-d4N1FXsPcewuVrm4C5y-IZ3eg-5M&libraries=places&language=<?php echo pll_current_language('slug'); ?>"></script>
    <script>
      function initMap() {
		const defaultLocation = {lat: 50.4490244, lng: 30.5201343}
		var map = new google.maps.Map(document.getElementById('map_canvas'), {
          center: defaultLocation,
          zoom: 11
        });
		var geocoder = new google.maps.Geocoder;
    var input = document.getElementById('cc_address');
    const submit = document.getElementById('add_address')
    const address_list = document.getElementById('address_list')
	const cc_address_list = document.getElementById('cc_address_list')
    const input_address_num = document.getElementById('address_num')
    const cc_city_id = document.getElementById('cc_city_id')
    const arr = []
    let IDs = {
		streets: [],
		cities: []
	}
	const newIDs = {
		streets: [],
		cities: []
	}
		
    function show() {
		IDs.streets = JSON.parse(cc_address_list.value)
		IDs.cities = JSON.parse(cc_city_id.value)
    	IDs.streets.map(placeId => {
    		geocoder.geocode({'placeId': placeId}, function(results, status) {
              if (status === google.maps.GeocoderStatus.OK) {
                if (results[0]) {
                	const place = results[0]
                  map.setZoom(13);
                  map.setCenter(place.geometry.location);
                  let marker = new google.maps.Marker({
                    map: map,
                    position: place.geometry.location
                  });
                  
                  const city = place.address_components[3].long_name
                  
                  const placeObj = {
                    placeId: placeId,
                    location: place.geometry.location,
                    name: place.formatted_address
                  }
                  
                  arr.push({
                  	place: placeObj,
                    marker: marker
                  })
                  
                  showAddress()
                }
              }
            });      
      })

    }
	
	    var options = {
        types: ['address'],
	      componentRestrictions: {country: 'ua'}
	    };
	
  		const findMarker = new google.maps.Marker({
          map: map
        });
        
      let currPlace = {}
      
	    var autocomplete = new google.maps.places.Autocomplete(input, options);
        autocomplete.bindTo('bounds', map);
	
        autocomplete.addListener('place_changed', function() {
          var place = autocomplete.getPlace();
            if (!place.geometry) {
              return;
            }

            if (place.geometry.viewport) {
              map.fitBounds(place.geometry.viewport);
            } else {
              map.setCenter(place.geometry.location);
              map.setZoom(13);
            }
            
            currPlace = {
               placeId: place.place_id,
               location: place.geometry.location,
               name: place.formatted_address,
               city: place.address_components[3].long_name
            }
			            
            findMarker.setPlace({
            	location: place.geometry.location,
              placeId: place.place_id
            });
            findMarker.setVisible(true);

        });
                
        submit.addEventListener('click', () => {
        	if (currPlace.placeId && arr.length < 4) {
            let newMarker = new google.maps.Marker({
              map: map,
              position: currPlace.location
            })
            map.setZoom(11)
            newMarker.setVisible(true)
            findMarker.setVisible(false)
            input.value = ''
				
            arr.push({
            	place: currPlace,
              marker: newMarker
            })
				
			geocoder.geocode({'location': currPlace.location}, (results, status) => {
				if (status === google.maps.GeocoderStatus.OK) {
					if(results[0]){
						newIDs.streets.push(currPlace.placeId)
						
						let cities = ''
						results.map(res => {
							if (res.types.indexOf('locality') > -1 || res.types.indexOf('administrative_area_level_1') > -1) {
								cities += res.place_id
							}
						})
						
			  			newIDs.cities.push(cities)
						
						cc_address_list.value = JSON.stringify(newIDs.streets)
      					cc_city_id.value = JSON.stringify(newIDs.cities)
				  }
				}
			})
				

            showAddress()
          }
        })
        
        function showAddress() {
        	address_list.innerHTML = ''
          
        	arr.map((obj, pos) => {
          	const id = `address_${pos}`
            const del_id = `delete_${pos}`
            
            address_list.innerHTML += 
							`
                <div class="address_container add-address-container">
                  <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/location-pin-red.svg" class="address-add__icon" />
                  <div class="formated_address">${obj.place.name}</div>
                  <input type="button" id="${del_id}" data-pos="${pos}" value="Видалити" class="delete_btn" />
                </div>
              `          	
				
            let del_btn = document.getElementById(del_id)
            del_btn.addEventListener('click', () => {
            	let index = parseInt(del_btn.dataset.pos)
              arr.splice(index, 1)
			        newIDs.streets.splice(index, 1)
				newIDs.cities.splice(index, 1)
              obj.marker.setMap(null)
				
							cc_address_list.value = JSON.stringify(newIDs.streets)
            	cc_city_id.value = JSON.stringify(newIDs.cities)
			
            	showAddress()
            })
          })
  
        }
        show()
      }
	  google.maps.event.addDomListener(window, 'load', initMap);
  </script>
  <?php
  }

?>