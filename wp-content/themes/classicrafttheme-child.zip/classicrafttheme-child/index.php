<?php get_header(); ?>
<section>
  <div class="container-color">
    <div class="container">
        <div class="top-text"><b class="bold">Орендуйте</b> будівельну техніку</br>та інструменти</div>
        <div class="categories-banner">
            <div class="categories-banner__column">
                <div class="categories-banner__column-title">
                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/jackhammer.svg" class="cat-icon" />
                    <span>Електричні</br>інструменти</span>
                </div>
                <div class="categories-banner__column-item">
                    <a href="<?php echo home_url('cate/vidbiini-molotky'); ?>">Відбійні молотки</a>
                </div>
                <div class="categories-banner__column-item">
                    <a href="<?php echo home_url('cate/'); ?>"></a>
                </div>
                <div class="categories-banner__column-item">
                <a href="<?php echo home_url('cate/'); ?>"></a>
                </div>
                <div class="categories-banner__column-item">
                    <a href="<?php echo home_url('cate/'); ?>"></a>
                </div>
                <div class="categories-banner__column-item">
                    <a href="<?php echo home_url('cate/'); ?>"></a>
                </div>
                <div class="categories-banner__column-item">
                    <a>Відбійні молотки</a>
                </div>
                <div class="categories-banner__column-item">
                    <a>Відбійні молотки</a>
                </div>
            </div>
            <div class="categories-banner__column">
                <div class="categories-banner__column-title">
                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/tractor.svg" class="cat-icon" />
                    <span>Спецтехніка</span>
                </div>
                <div class="categories-banner__column-item">
                    <a>Відбійні молотки</a>
                </div>
                <div class="categories-banner__column-item">
                    <a>Відбійні молотки</a>
                </div>
                <div class="categories-banner__column-item">
                    <a>Відбійні молотки</a>
                </div>
                <div class="categories-banner__column-item">
                    <a>Відбійні молотки</a>
                </div>
                <div class="categories-banner__column-item">
                    <a>Відбійні молотки</a>
                </div>
                <div class="categories-banner__column-item">
                    <a>Відбійні молотки</a>
                </div>
                <div class="categories-banner__column-item">
                    <a>Відбійні молотки</a>
                </div>
            </div>
            <div class="categories-banner__column">
                <div class="categories-banner__column-title">
                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/circular-saw.svg" class="cat-icon" />
                    <span>Обладнання</span>
                </div>
                <div class="categories-banner__column-item">
                    <a>Відбійні молотки</a>
                </div>
                <div class="categories-banner__column-item">
                    <a>Відбійні молотки</a>
                </div>
                <div class="categories-banner__column-item">
                    <a>Відбійні молотки</a>
                </div>
                <div class="categories-banner__column-item">
                    <a>Відбійні молотки</a>
                </div>
                <div class="categories-banner__column-item">
                    <a>Відбійні молотки</a>
                </div>
                <div class="categories-banner__column-item">
                    <a>Відбійні молотки</a>
                </div>
            </div>
            <div class="categories-banner__column">
                <div class="categories-banner__column-title">
                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/crane-machine.svg" class="cat-icon" />
                    <span>Підйомна</br>техніка</span>
                </div>
                <div class="categories-banner__column-item">
                    <a>Відбійні молотки</a>
                    <div class="categories-banner__column-item">
                    <a>Відбійні молотки</a>
                </div>
                <div class="categories-banner__column-item">
                    <a>Відбійні молотки</a>
                </div>
                <div class="categories-banner__column-item">
                    <a>Відбійні молотки</a>
                </div>
                <div class="categories-banner__column-item">
                    <a>Відбійні молотки</a>
                </div>
                </div>
            </div>
        </div>
        <!-- <div class="banners-categories">
            <?php
                        $categories = get_categories(array(
                            'taxonomy' => 'cate',
                            'hide_empty' => true,
                            'parent'=>0,
                        ));
                        foreach ( $categories as $category )
                            echo '
                                <a href="'.esc_url( get_category_link( $category->term_id ) ).'" class="banners-categories__category-item">
                                    <div class="banners-categories__category-item__text">'.esc_html( $category->name ).'</div>
                                    <img src="'.get_stylesheet_directory_uri().'/img/arrow-down-sign-to-navigate.svg" class="banners-categories__category-item__arrow" />
                                </a>
                            '
                    ?>
        </div>
        <div class="banners-big">
            <div class="banners-big__text"><b class="bold">Орендуйте</b><br/> будівельну техніку <br/> та інструменти</div> 
        </div>
        <div class="banners-num">
            <div>
                <div class="banners-num__text banners-num__text__big">12,000+</div>
                <div class="banners-num__text banners-num__text__small">оголошень за останні 30 днів</div>
            </div>
        </div>
        <div class="banners-add">
            <img class="ico chart-ico" src="<?php echo get_stylesheet_directory_uri(); ?>/img/bars.svg"/>
            <div class="banners-num__text banners-num__text__small">Розмістіть безкоштовне<br/>оголошення та заробляйте</div>
            <a href="<?php echo home_url('ad-new/'); ?>" class="banners-num__add-btn">
                  <i class="fa fa-plus" aria-hidden="true"></i>
                    Подати оголошення
            </a>
        </div>
        <a href="<?php echo home_url('cate/akumuliatorni-instrumenty/'); ?>" class="banners-add__mobile-btn">Категорії оголошень</a> -->
    </div>
  </div>
	<?php if(is_premium()) : ?>  
    <div class="group-product group-product_premium group-product_grid">
        <h3 class="group-product__title">Преміум оголошення</h3>
				
        <div class="container">
             <div class="content">
			     <div class="gallery text-center">
			     <?php
				    $limit = get_option('posts_per_page');
					
				    query_posts(array(
                       'post_type' => POST_TYPE,
                       'posts_per_page' => $limit,
                       'meta_query' => array(
                           array(
                              'key' => 'cc_add_type',
                              'value' => 'pro',
                              'compare' => 'NOT NULL',
                           ),
                           array(
                               'key' => 'cc_add_type',
                               'value' => 'draft',
                               'compare' => '!='
                           )
                        )
                    ));
					
				    if (have_posts()) :                   
                      while (have_posts()) : the_post();
				  ?>
                    <div class="gallery-item">
                        <div class="product-item">
                            <div class="product-item__img">
							    <div class="group-product_premium__label">Преміум</div>
                                <?php echo ad_thumbnail(); ?>
                            </div>
                            <a href="<?php the_permalink() ?>" class="product-item__container-title">
                              <div class="product-item__title">
                                 <?php echo title_excerpt(); ?>
                              </div>
                              <?php echo price_output(); ?>
                            </a>
                        </div>
                    </div>
					
					<?php endwhile; endif; wp_reset_query(); ?>
					
                </div>
            </div>  
        </div>
    </div>
		<?php endif; ?>
				
</section>
<section>
    <div class="container">
        <div class="group-product group-product_top group-product_grid">
            <h3 class="group-product__title">Популярні оглошення</h3>
            <div class="row">
                <div class="content">
                    <div class="gallery text-center">
					<?php
                    query_posts(array(
                       'post_type' => POST_TYPE,
                       'showposts' => 10,
					   'meta_key'=>'post_views_count', 
					   'orderby' => 'meta_value_num',
                       'order' => DESC,
                       'meta_query' => array(
                            array(
                                'key' => 'cc_add_type',
                                'value' => 'draft',
                                'compare' => '!='
                            )
                       )
                    ));
                    if (have_posts()) :
                        while (have_posts()) : the_post();
                    ?>
                    <div class="gallery-item">
                        <div class="product-item">
                            <div class="product-item__img">
                                <?php echo ad_thumbnail(); ?>
                            </div>
                            <a href="<?php the_permalink() ?>" class="product-item__container-title">
                              <div class="product-item__title">
                                 <?php echo title_excerpt(); ?>
                              </div>
                              <?php echo price_output(); ?>
                            </a>
                        </div>
                    </div>
						
						<?php endwhile; endif; wp_reset_query(); ?>
						
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section>
    <div class="container">
        <div class="group-product group-product_top group-product_grid">
            <h3 class="group-product__title">Останні оголошення</h3>
            <div class="row">
                <div class="content">
                    <div class="gallery text-center">
					<?php
                    query_posts(array(
                       'post_type' => POST_TYPE,
                       'showposts' => 5,
                       'orderby' => 'date',
                       'meta_query' => array(
                        array(
                            'key' => 'cc_add_type',
                            'value' => 'draft',
                            'compare' => '!='
                        )
                       )
/*                     'meta_query' => array(
                           array(
                               'key' => 'cc_f_checkbox1',
                               'value' => 'on',
                               'compare' => 'NOT NULL',
                           )
                        )
*/
                    ));
				    if (have_posts()) :                   
                        while (have_posts()) : the_post();
				    ?>
                    <div class="gallery-item">
                    <div class="product-item">
                        <div class="product-item__img">
                            <?php echo ad_thumbnail(); ?>
                        </div>
                        <a href="<?php the_permalink() ?>" class="product-item__container-title">
                          <div class="product-item__title">
                             <?php echo title_excerpt(); ?>
                          </div>
                          <?php echo price_output(); ?>
                        </a>
                    </div>
                </div>
						
						<?php endwhile; endif; wp_reset_query(); ?>
						
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section>
        <div class="container">
            <div class="footer-text">
            Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.

The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. RackhamContrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.

The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham
            </div>
        </div>
    </section>

<!--End Cotent Wrapper-->

<?php get_footer(); ?>
