<?php
  get_header();

    if (isset($_GET['author_name'])) :
            $curauth = get_user_by('login', $author_name);
    else :
        $curauth = get_userdata(intval($author));
    endif;

    $ava = get_the_author_meta( 'user_avatar', $curauth->ID );
	if( !$ava ) $ava = get_stylesheet_directory_uri() .'/img/no-avatar.png';
  
  if (have_posts()) :
    while (have_posts()): the_post();
	  $current_post_id = $post->ID;
      $taxonomies = get_the_term_list($post->ID, CUSTOM_CAT_TYPE, '', ' ', '');
	  $author_id = $post->post_author;
	  $ad_type = get_post_meta($post->ID, 'cc_add_type', true);
	  $skype = get_the_author_meta('skype');
	  $phone = get_the_author_meta('phone');
	  $website = get_the_author_meta('url');
	  $main_img = get_post_meta( $post->ID, 'img1', true );
      $awards = get_the_author_meta( 'awards', $author_id );
      $state = get_post_meta($post->ID, 'cc_state', true);
?>
<!-- Content -->
<section class="advert_section">
    <div class="container">
        <div class="advert">
		
		  <?php if( $post->post_status == "draft" ) : ?>
		  <div class="notification mess-info mess-info_center">
            Це оголошення більше не актуальне
          </div>
		  <?php endif; ?>

            <div class="title title_grid">
                <div class="title_advert"><?php the_title(); ?></div>
                <?php
                    if( $ad_type == "pro" ) echo '<div class="title__prem">Преміум</div>';
                    ?>
            </div>
            <div class="advert_grid">
			
			    <?php  if( $main_img && file_url_exists( $main_img )) : ?>
				
                <div class="advert__img-wrap">
                  <a href="<?php echo $main_img; ?>"   class = "fancybox" title="" rel="gallery1">
				    <img src="<?php echo $main_img; ?>" alt="adv" class="advert__img-big " style="display:block;">
				  </a>
				  <ul class="advert__img-wrap">
				  <?php 
				    $img2 = get_post_meta( $post->ID, 'img2', true );
					$img3 = get_post_meta( $post->ID, 'img3', true );
					if( $img2 && file_url_exists( $img2 )) :
					  $src_info = pathinfo( $img2 );
                      $img2_resized = $src_info['dirname'].'/'.$src_info['filename']."_145X86.".$src_info['extension'];
					  $imgsrc2 = file_url_exists( $img2_resized ) ? $img2_resized : $img2;
				  ?>
                    <li class="advert__img-item">
					  <a href="<?php echo $img2; ?>"  class="advert__img-link fancybox" title="" rel="gallery1">
                        <img src="<?php echo $imgsrc2; ?>" alt="ad-photo">
					  </a>
				    </li>
				  <?php endif;
				    if( $img3 && file_url_exists( $img3 )) :
				      $src_info = pathinfo( $img3 );
                      $img3_resized = $src_info['dirname'].'/'.$src_info['filename']."_145X86.".$src_info['extension'];
					  $imgsrc3 = file_url_exists( $img3_resized ) ? $img3_resized : $img3;
					?>
					<li class="advert__img-item">
					  <a href="<?php echo $img3; ?>"  class="advert__img-link fancybox" title="" rel="gallery1">
                        <img src="<?php echo $imgsrc3; ?>" alt="ad-photo">
					  </a>
				    </li>
					<?php endif; ?>
				  </ul>
                </div>
				
				<?php endif; ?>
				
                <div class="advert__tags">
                    <div class="advert__tags advert__tags_grid">
                        <h3 class="advert__tags-title">Категорія</h3>
						<?php echo $taxonomies; ?>
                    </div>
					<div class="advert__tags advert__tags_grid">
                        <h3 class="advert__tags-title">Додано</h3>
						<span><?php the_time(); ?>, </span>
						<span><?php the_date(); ?></span>
                    </div>
                    <div class="advert__tags advert__tags_grid">
					
					<?php if( $author_id != $user_ID ) cc_setPostViews(get_the_ID()); ?>
					
                        <h3 class="advert__tags-title">Перегляди: <span><?php echo cc_getPostViews(get_the_ID()); ?></span></h3>
                    </div>
                </div>
                <div class="advert__descr">
                    <h3>Опис</h3>
                    <?php the_content(); ?>
                </div>
                <div class="soc-wrap">
				<?php echo do_shortcode('[supsystic-social-sharing id="1"]') ?>
                </div>
				
				<?php if( $author_id != $user_ID ) : ?>
                <div class="advert__mess-wrp" id="write">
                    <?php include_once( get_stylesheet_directory() . '/sweet_leads.php'); ?>
                </div>
				<?php endif; ?>
				
            </div>
            <div class="aside_grid">
                <div class="aside">
                
                    <div class="contact-ad__container">
				        <?php echo price_output(); ?>
                    </div>

                    <div class="contact-ad__container">
                        <div class="author-side__name">
                            <img class="contact-ad__author-photo" src="<?php echo $ava; ?>" />
                            <div class="contact-ad__author-text">
                                <?php echo the_author_posts_link(); ?>
                                <div class="contact-ad__author-city">м. Київ</div>
                            </div>
                        </div>
                    </div>
				
					<?php if ( $phone ) : ?>
                    <div class="tel">
                        <div>
                            <img class="tel-icon" src="<?php echo get_stylesheet_directory_uri(); ?>/img/call-answer.svg" />
                            <span id="tel<?php echo $post->ID; ?>" class="nuber-tel nuber-tel_big"></span>
                        </div>
                        <span class="btn btn_view" id="viewbtn2" >Відкрити</span>
                    </div>
					<?php endif; ?>
                    <?php if ( $skype ) : ?>
                    <a href="skype:<?php echo $skype; ?>?chat" onclick="Skype.tryAnalyzeSkypeUri('call', '0');" >
                        <div class="contact__skype">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/Skype_icon.png" class="tel-icon" />
                            <span class="contact__text"><?php echo $skype; ?></span>                                
                        </div>
                    </a>
            	    <?php endif; ?>
                    <?php if ($author_id != $user_ID) : ?>
                        <a href="#write">
                            <div class="contact__write">
                                <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/speech-bubbles.svg" class="tel-icon" />
                                <span class="contact__text">Написати автору</span>
                            </div>
                        </a>
                    <?php endif ?>
                    <div class="maps-wrp" style="height: 300px;">
                        <div class="maps__title">Доступно в локаціях</div>
						<div id='address_list'></div>
						<input id="cc_address_list" type="hidden" value='<?php echo get_post_meta($post->ID, 'cc_address_list', true); ?>' />
                        <div class="maps">
						  <div id="map_canvas"></div>
                        </div>
                    </div>
                    <div class="author-side">
                        <div class="rating">
                         
                         
                        </div>       
						<span class="numtel hide"><?php echo $phone; ?></span>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<?php endwhile; endif; wp_reset_query(); ?>

<?php
  query_posts(array(
    'post_type' => POST_TYPE,
    'posts_per_page' => -1,
    'author' => $author_id
  ));
  $count = 0;
  if (have_posts()) : while (have_posts()) { the_post(); $count++; }
  if ( $count > 1 ) :
?>
<section>
    <div class="container">
        <div class="group-product group-product_grid">
            <h3 class="group-product__title">Інші оголошення від цього автора</h3>
            <div class="row">
                <div class="content">
                    <div class="gallery text-center">
                        <div class="wrap-carousel wrap-carousel_other wrap-carousel_advert">
                            <div class="carousel" id="authorSlick">
							    <?php
						            while (have_posts()): the_post();
									  if( $current_post_id == $post->ID) continue;
                                ?>
								<div class = "carousel__item">
                                    <div class="gallery-item">
                                        <div class="product-item">
                                            <div class="product-item__img">
                                                <?php echo ad_thumbnail(); ?>
                                            </div>
                                            <a href="<?php the_permalink() ?>" class="product-item__container-title">
                                            <div class="product-item__title">
                                                <?php echo title_excerpt(); ?>
                                            </div>
                                            <?php echo price_output(); ?>
                                            </a>
                                        </div>
                                    </div>
                                </div>
								<?php endwhile; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; endif; wp_reset_query(); ?>

<?php get_footer(); ?>