<!--Start Sidebar-->
    <div class="menu-cat_grid">
          <div class="cat-mobile">
          <a href="#0" class="btn btn_mobile btn_mobile-cat" id="catBtn">Категорії</a>
          <div class="menu-cat__title">Місто</div>
            <div class="location location_cat">
                <div class="input-wrp input-wrp_location">
                    <span class="ico target-ico"></span>
                      <!--<label class="input__label" id="label">Київ</label>-->
                    <input type="text" id="cat_address" placeholder="<?php echo __( 'All Ukraine', 'cc' ); ?>" class="input input_location" value="<?php if( isset($_GET['city']) ) echo $_GET['city']; ?>">
					<a id="cat_address_link" href="" class="link link_blue link_abs fright"><?php echo __( 'Change', 'cc' ); ?></a>
                </div>
            </div>
            <div class="menu-cat__title">Категорії</div>
		    <ul class="menu-cat">
            <?php
		      $cat_args = array(
			    'orderby' => 'name',
			    'show_count' => 0,
			    'hierarchical' => 1,
			    'taxonomy' => 'cate',
			    'hide_empty' => 1,
				'style' => 'list',
			    'title_li' => '',
				'walker' => new Custom_Walker_Category(),
		      );
              wp_list_categories($cat_args);
            ?>
            </ul>
        </div>
    </div>
<!--End Sidebar-->